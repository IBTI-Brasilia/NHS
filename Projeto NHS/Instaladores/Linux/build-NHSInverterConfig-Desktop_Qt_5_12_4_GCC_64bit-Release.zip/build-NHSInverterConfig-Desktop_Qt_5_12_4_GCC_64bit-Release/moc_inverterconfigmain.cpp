/****************************************************************************
** Meta object code from reading C++ file 'inverterconfigmain.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../nhs-inverter-configtool/inverterconfigmain.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'inverterconfigmain.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_InverterConfigMain_t {
    QByteArrayData data[46];
    char stringdata0[807];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_InverterConfigMain_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_InverterConfigMain_t qt_meta_stringdata_InverterConfigMain = {
    {
QT_MOC_LITERAL(0, 0, 18), // "InverterConfigMain"
QT_MOC_LITERAL(1, 19, 16), // "updateUIAboutTab"
QT_MOC_LITERAL(2, 36, 0), // ""
QT_MOC_LITERAL(3, 37, 14), // "sIDInfoDataGWE"
QT_MOC_LITERAL(4, 52, 4), // "info"
QT_MOC_LITERAL(5, 57, 14), // "sIDInfoDataGWT"
QT_MOC_LITERAL(6, 72, 15), // "updateUIInfoTab"
QT_MOC_LITERAL(7, 88, 16), // "sRunningInfoData"
QT_MOC_LITERAL(8, 105, 15), // "sGWTRunInfoData"
QT_MOC_LITERAL(9, 121, 24), // "updateUIpowerFactorLabel"
QT_MOC_LITERAL(10, 146, 7), // "wewratt"
QT_MOC_LITERAL(11, 154, 21), // "updateUIRectTimeLabel"
QT_MOC_LITERAL(12, 176, 8), // "uint16_t"
QT_MOC_LITERAL(13, 185, 17), // "updateUIConfigTab"
QT_MOC_LITERAL(14, 203, 17), // "sInverterConfigUI"
QT_MOC_LITERAL(15, 221, 6), // "config"
QT_MOC_LITERAL(16, 228, 22), // "updateUICurrentRTCTime"
QT_MOC_LITERAL(17, 251, 16), // "sInverterRTCTime"
QT_MOC_LITERAL(18, 268, 4), // "time"
QT_MOC_LITERAL(19, 273, 10), // "yearOffset"
QT_MOC_LITERAL(20, 284, 17), // "updateUIStatusBar"
QT_MOC_LITERAL(21, 302, 4), // "stat"
QT_MOC_LITERAL(22, 307, 20), // "confirmNewSettingsUI"
QT_MOC_LITERAL(23, 328, 7), // "uint8_t"
QT_MOC_LITERAL(24, 336, 5), // "check"
QT_MOC_LITERAL(25, 342, 9), // "prepareUI"
QT_MOC_LITERAL(26, 352, 15), // "eDecideInverter"
QT_MOC_LITERAL(27, 368, 6), // "modelo"
QT_MOC_LITERAL(28, 375, 19), // "confirmNewRTCTimeUI"
QT_MOC_LITERAL(29, 395, 23), // "confirmNewPowerFactorUI"
QT_MOC_LITERAL(30, 419, 14), // "openSerialPort"
QT_MOC_LITERAL(31, 434, 15), // "Serial_Settings"
QT_MOC_LITERAL(32, 450, 26), // "on_actionConnect_triggered"
QT_MOC_LITERAL(33, 477, 29), // "on_actionDisconnect_triggered"
QT_MOC_LITERAL(34, 507, 30), // "on_pushButtonConfigure_clicked"
QT_MOC_LITERAL(35, 538, 27), // "on_tabWidget_currentChanged"
QT_MOC_LITERAL(36, 566, 25), // "on_pushButtonSync_clicked"
QT_MOC_LITERAL(37, 592, 44), // "on_comboBoxOutputVoltage_curr..."
QT_MOC_LITERAL(38, 637, 5), // "index"
QT_MOC_LITERAL(39, 643, 27), // "updateDetailedConfiguration"
QT_MOC_LITERAL(40, 671, 14), // "eOutputVoltage"
QT_MOC_LITERAL(41, 686, 7), // "voltage"
QT_MOC_LITERAL(42, 694, 20), // "configure_serialPort"
QT_MOC_LITERAL(43, 715, 22), // "on_ScanPorts_triggered"
QT_MOC_LITERAL(44, 738, 31), // "on_actionSerialConfig_triggered"
QT_MOC_LITERAL(45, 770, 36) // "on_pushButtonConfPowerFactor_..."

    },
    "InverterConfigMain\0updateUIAboutTab\0"
    "\0sIDInfoDataGWE\0info\0sIDInfoDataGWT\0"
    "updateUIInfoTab\0sRunningInfoData\0"
    "sGWTRunInfoData\0updateUIpowerFactorLabel\0"
    "wewratt\0updateUIRectTimeLabel\0uint16_t\0"
    "updateUIConfigTab\0sInverterConfigUI\0"
    "config\0updateUICurrentRTCTime\0"
    "sInverterRTCTime\0time\0yearOffset\0"
    "updateUIStatusBar\0stat\0confirmNewSettingsUI\0"
    "uint8_t\0check\0prepareUI\0eDecideInverter\0"
    "modelo\0confirmNewRTCTimeUI\0"
    "confirmNewPowerFactorUI\0openSerialPort\0"
    "Serial_Settings\0on_actionConnect_triggered\0"
    "on_actionDisconnect_triggered\0"
    "on_pushButtonConfigure_clicked\0"
    "on_tabWidget_currentChanged\0"
    "on_pushButtonSync_clicked\0"
    "on_comboBoxOutputVoltage_currentIndexChanged\0"
    "index\0updateDetailedConfiguration\0"
    "eOutputVoltage\0voltage\0configure_serialPort\0"
    "on_ScanPorts_triggered\0"
    "on_actionSerialConfig_triggered\0"
    "on_pushButtonConfPowerFactor_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_InverterConfigMain[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      25,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  139,    2, 0x0a /* Public */,
       1,    1,  142,    2, 0x0a /* Public */,
       6,    1,  145,    2, 0x0a /* Public */,
       6,    1,  148,    2, 0x0a /* Public */,
       9,    2,  151,    2, 0x0a /* Public */,
      11,    2,  156,    2, 0x0a /* Public */,
      13,    1,  161,    2, 0x0a /* Public */,
      16,    2,  164,    2, 0x0a /* Public */,
      20,    1,  169,    2, 0x0a /* Public */,
      22,    1,  172,    2, 0x0a /* Public */,
      25,    2,  175,    2, 0x0a /* Public */,
      28,    1,  180,    2, 0x0a /* Public */,
      29,    1,  183,    2, 0x0a /* Public */,
      30,    1,  186,    2, 0x0a /* Public */,
      32,    0,  189,    2, 0x08 /* Private */,
      33,    0,  190,    2, 0x08 /* Private */,
      34,    0,  191,    2, 0x08 /* Private */,
      35,    0,  192,    2, 0x08 /* Private */,
      36,    0,  193,    2, 0x08 /* Private */,
      37,    1,  194,    2, 0x08 /* Private */,
      39,    1,  197,    2, 0x08 /* Private */,
      42,    1,  200,    2, 0x08 /* Private */,
      43,    0,  203,    2, 0x08 /* Private */,
      44,    0,  204,    2, 0x08 /* Private */,
      45,    0,  205,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 5,    4,
    QMetaType::Void, 0x80000000 | 7,    4,
    QMetaType::Void, 0x80000000 | 8,    4,
    QMetaType::Void, QMetaType::Float, QMetaType::Bool,    4,   10,
    QMetaType::Void, 0x80000000 | 12, QMetaType::Bool,    4,   10,
    QMetaType::Void, 0x80000000 | 14,   15,
    QMetaType::Void, 0x80000000 | 17, 0x80000000 | 12,   18,   19,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void, 0x80000000 | 23,   24,
    QMetaType::Void, 0x80000000 | 26, QMetaType::QByteArray,   24,   27,
    QMetaType::Void, 0x80000000 | 23,   24,
    QMetaType::Void, QMetaType::Bool,   24,
    QMetaType::Void, 0x80000000 | 31,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   38,
    QMetaType::Void, 0x80000000 | 40,   41,
    QMetaType::Void, 0x80000000 | 31,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void InverterConfigMain::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<InverterConfigMain *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateUIAboutTab((*reinterpret_cast< sIDInfoDataGWE(*)>(_a[1]))); break;
        case 1: _t->updateUIAboutTab((*reinterpret_cast< sIDInfoDataGWT(*)>(_a[1]))); break;
        case 2: _t->updateUIInfoTab((*reinterpret_cast< sRunningInfoData(*)>(_a[1]))); break;
        case 3: _t->updateUIInfoTab((*reinterpret_cast< sGWTRunInfoData(*)>(_a[1]))); break;
        case 4: _t->updateUIpowerFactorLabel((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 5: _t->updateUIRectTimeLabel((*reinterpret_cast< uint16_t(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 6: _t->updateUIConfigTab((*reinterpret_cast< sInverterConfigUI(*)>(_a[1]))); break;
        case 7: _t->updateUICurrentRTCTime((*reinterpret_cast< sInverterRTCTime(*)>(_a[1])),(*reinterpret_cast< uint16_t(*)>(_a[2]))); break;
        case 8: _t->updateUIStatusBar((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 9: _t->confirmNewSettingsUI((*reinterpret_cast< uint8_t(*)>(_a[1]))); break;
        case 10: _t->prepareUI((*reinterpret_cast< eDecideInverter(*)>(_a[1])),(*reinterpret_cast< QByteArray(*)>(_a[2]))); break;
        case 11: _t->confirmNewRTCTimeUI((*reinterpret_cast< uint8_t(*)>(_a[1]))); break;
        case 12: _t->confirmNewPowerFactorUI((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 13: _t->openSerialPort((*reinterpret_cast< Serial_Settings(*)>(_a[1]))); break;
        case 14: _t->on_actionConnect_triggered(); break;
        case 15: _t->on_actionDisconnect_triggered(); break;
        case 16: _t->on_pushButtonConfigure_clicked(); break;
        case 17: _t->on_tabWidget_currentChanged(); break;
        case 18: _t->on_pushButtonSync_clicked(); break;
        case 19: _t->on_comboBoxOutputVoltage_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->updateDetailedConfiguration((*reinterpret_cast< eOutputVoltage(*)>(_a[1]))); break;
        case 21: _t->configure_serialPort((*reinterpret_cast< Serial_Settings(*)>(_a[1]))); break;
        case 22: _t->on_ScanPorts_triggered(); break;
        case 23: _t->on_actionSerialConfig_triggered(); break;
        case 24: _t->on_pushButtonConfPowerFactor_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< sRunningInfoData >(); break;
            }
            break;
        case 3:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< sGWTRunInfoData >(); break;
            }
            break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< sInverterRTCTime >(); break;
            }
            break;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject InverterConfigMain::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_InverterConfigMain.data,
    qt_meta_data_InverterConfigMain,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *InverterConfigMain::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *InverterConfigMain::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_InverterConfigMain.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int InverterConfigMain::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
