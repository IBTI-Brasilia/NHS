/****************************************************************************
** Meta object code from reading C++ file 'InverterComm.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../nhs-inverter-configtool/InverterComm.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'InverterComm.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_InverterComm_t {
    QByteArrayData data[37];
    char stringdata0[497];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_InverterComm_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_InverterComm_t qt_meta_stringdata_InverterComm = {
    {
QT_MOC_LITERAL(0, 0, 12), // "InverterComm"
QT_MOC_LITERAL(1, 13, 14), // "connectionLost"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 14), // "updateAboutTab"
QT_MOC_LITERAL(4, 44, 14), // "sIDInfoDataGWE"
QT_MOC_LITERAL(5, 59, 4), // "info"
QT_MOC_LITERAL(6, 64, 14), // "sIDInfoDataGWT"
QT_MOC_LITERAL(7, 79, 17), // "updatePowerFactor"
QT_MOC_LITERAL(8, 97, 8), // "powerFac"
QT_MOC_LITERAL(9, 106, 7), // "wewratt"
QT_MOC_LITERAL(10, 114, 13), // "updateRecTime"
QT_MOC_LITERAL(11, 128, 8), // "uint16_t"
QT_MOC_LITERAL(12, 137, 7), // "recTime"
QT_MOC_LITERAL(13, 145, 13), // "updateInfoTab"
QT_MOC_LITERAL(14, 159, 16), // "sRunningInfoData"
QT_MOC_LITERAL(15, 176, 15), // "sGWTRunInfoData"
QT_MOC_LITERAL(16, 192, 15), // "updateConfigTab"
QT_MOC_LITERAL(17, 208, 17), // "sInverterConfigUI"
QT_MOC_LITERAL(18, 226, 6), // "config"
QT_MOC_LITERAL(19, 233, 21), // "updateConfigSerialTab"
QT_MOC_LITERAL(20, 255, 15), // "Serial_Settings"
QT_MOC_LITERAL(21, 271, 9), // "cfgSerial"
QT_MOC_LITERAL(22, 281, 20), // "updateCurrentRTCTime"
QT_MOC_LITERAL(23, 302, 16), // "sInverterRTCTime"
QT_MOC_LITERAL(24, 319, 4), // "time"
QT_MOC_LITERAL(25, 324, 10), // "yearOffset"
QT_MOC_LITERAL(26, 335, 15), // "updateStatusBar"
QT_MOC_LITERAL(27, 351, 4), // "stat"
QT_MOC_LITERAL(28, 356, 20), // "prepareUI_goodWe_GWT"
QT_MOC_LITERAL(29, 377, 15), // "eDecideInverter"
QT_MOC_LITERAL(30, 393, 5), // "check"
QT_MOC_LITERAL(31, 399, 6), // "modelo"
QT_MOC_LITERAL(32, 406, 18), // "confirmNewSettings"
QT_MOC_LITERAL(33, 425, 7), // "uint8_t"
QT_MOC_LITERAL(34, 433, 21), // "confirmNewPowerFactor"
QT_MOC_LITERAL(35, 455, 17), // "confirmNewRTCTime"
QT_MOC_LITERAL(36, 473, 23) // "timerPoolDeviceCallback"

    },
    "InverterComm\0connectionLost\0\0"
    "updateAboutTab\0sIDInfoDataGWE\0info\0"
    "sIDInfoDataGWT\0updatePowerFactor\0"
    "powerFac\0wewratt\0updateRecTime\0uint16_t\0"
    "recTime\0updateInfoTab\0sRunningInfoData\0"
    "sGWTRunInfoData\0updateConfigTab\0"
    "sInverterConfigUI\0config\0updateConfigSerialTab\0"
    "Serial_Settings\0cfgSerial\0"
    "updateCurrentRTCTime\0sInverterRTCTime\0"
    "time\0yearOffset\0updateStatusBar\0stat\0"
    "prepareUI_goodWe_GWT\0eDecideInverter\0"
    "check\0modelo\0confirmNewSettings\0uint8_t\0"
    "confirmNewPowerFactor\0confirmNewRTCTime\0"
    "timerPoolDeviceCallback"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_InverterComm[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      15,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   94,    2, 0x06 /* Public */,
       3,    1,   95,    2, 0x06 /* Public */,
       3,    1,   98,    2, 0x06 /* Public */,
       7,    2,  101,    2, 0x06 /* Public */,
      10,    2,  106,    2, 0x06 /* Public */,
      13,    1,  111,    2, 0x06 /* Public */,
      13,    1,  114,    2, 0x06 /* Public */,
      16,    1,  117,    2, 0x06 /* Public */,
      19,    1,  120,    2, 0x06 /* Public */,
      22,    2,  123,    2, 0x06 /* Public */,
      26,    1,  128,    2, 0x06 /* Public */,
      28,    2,  131,    2, 0x06 /* Public */,
      32,    1,  136,    2, 0x06 /* Public */,
      34,    1,  139,    2, 0x06 /* Public */,
      35,    1,  142,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      36,    0,  145,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Bool,
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void, 0x80000000 | 6,    5,
    QMetaType::Void, QMetaType::Float, QMetaType::Bool,    8,    9,
    QMetaType::Void, 0x80000000 | 11, QMetaType::Bool,   12,    9,
    QMetaType::Void, 0x80000000 | 14,    5,
    QMetaType::Void, 0x80000000 | 15,    5,
    QMetaType::Void, 0x80000000 | 17,   18,
    QMetaType::Void, 0x80000000 | 20,   21,
    QMetaType::Void, 0x80000000 | 23, 0x80000000 | 11,   24,   25,
    QMetaType::Void, QMetaType::QString,   27,
    QMetaType::Void, 0x80000000 | 29, QMetaType::QByteArray,   30,   31,
    QMetaType::Void, 0x80000000 | 33,   30,
    QMetaType::Void, QMetaType::Bool,   30,
    QMetaType::Void, 0x80000000 | 33,   30,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void InverterComm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<InverterComm *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: { bool _r = _t->connectionLost();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 1: _t->updateAboutTab((*reinterpret_cast< sIDInfoDataGWE(*)>(_a[1]))); break;
        case 2: _t->updateAboutTab((*reinterpret_cast< sIDInfoDataGWT(*)>(_a[1]))); break;
        case 3: _t->updatePowerFactor((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 4: _t->updateRecTime((*reinterpret_cast< uint16_t(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 5: _t->updateInfoTab((*reinterpret_cast< sRunningInfoData(*)>(_a[1]))); break;
        case 6: _t->updateInfoTab((*reinterpret_cast< sGWTRunInfoData(*)>(_a[1]))); break;
        case 7: _t->updateConfigTab((*reinterpret_cast< sInverterConfigUI(*)>(_a[1]))); break;
        case 8: _t->updateConfigSerialTab((*reinterpret_cast< Serial_Settings(*)>(_a[1]))); break;
        case 9: _t->updateCurrentRTCTime((*reinterpret_cast< sInverterRTCTime(*)>(_a[1])),(*reinterpret_cast< uint16_t(*)>(_a[2]))); break;
        case 10: _t->updateStatusBar((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 11: _t->prepareUI_goodWe_GWT((*reinterpret_cast< eDecideInverter(*)>(_a[1])),(*reinterpret_cast< QByteArray(*)>(_a[2]))); break;
        case 12: _t->confirmNewSettings((*reinterpret_cast< uint8_t(*)>(_a[1]))); break;
        case 13: _t->confirmNewPowerFactor((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 14: _t->confirmNewRTCTime((*reinterpret_cast< uint8_t(*)>(_a[1]))); break;
        case 15: _t->timerPoolDeviceCallback(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< sRunningInfoData >(); break;
            }
            break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< sGWTRunInfoData >(); break;
            }
            break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< sInverterRTCTime >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = bool (InverterComm::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&InverterComm::connectionLost)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (InverterComm::*)(sIDInfoDataGWE );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&InverterComm::updateAboutTab)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (InverterComm::*)(sIDInfoDataGWT );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&InverterComm::updateAboutTab)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (InverterComm::*)(float , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&InverterComm::updatePowerFactor)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (InverterComm::*)(uint16_t , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&InverterComm::updateRecTime)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (InverterComm::*)(sRunningInfoData );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&InverterComm::updateInfoTab)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (InverterComm::*)(sGWTRunInfoData );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&InverterComm::updateInfoTab)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (InverterComm::*)(sInverterConfigUI );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&InverterComm::updateConfigTab)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (InverterComm::*)(Serial_Settings );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&InverterComm::updateConfigSerialTab)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (InverterComm::*)(sInverterRTCTime , uint16_t );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&InverterComm::updateCurrentRTCTime)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (InverterComm::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&InverterComm::updateStatusBar)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (InverterComm::*)(eDecideInverter , QByteArray );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&InverterComm::prepareUI_goodWe_GWT)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (InverterComm::*)(uint8_t );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&InverterComm::confirmNewSettings)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (InverterComm::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&InverterComm::confirmNewPowerFactor)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (InverterComm::*)(uint8_t );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&InverterComm::confirmNewRTCTime)) {
                *result = 14;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject InverterComm::staticMetaObject = { {
    &QThread::staticMetaObject,
    qt_meta_stringdata_InverterComm.data,
    qt_meta_data_InverterComm,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *InverterComm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *InverterComm::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_InverterComm.stringdata0))
        return static_cast<void*>(this);
    return QThread::qt_metacast(_clname);
}

int InverterComm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    }
    return _id;
}

// SIGNAL 0
bool InverterComm::connectionLost()
{
    bool _t0{};
    void *_a[] = { const_cast<void*>(reinterpret_cast<const void*>(&_t0)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
    return _t0;
}

// SIGNAL 1
void InverterComm::updateAboutTab(sIDInfoDataGWE _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void InverterComm::updateAboutTab(sIDInfoDataGWT _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void InverterComm::updatePowerFactor(float _t1, bool _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void InverterComm::updateRecTime(uint16_t _t1, bool _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void InverterComm::updateInfoTab(sRunningInfoData _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void InverterComm::updateInfoTab(sGWTRunInfoData _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void InverterComm::updateConfigTab(sInverterConfigUI _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void InverterComm::updateConfigSerialTab(Serial_Settings _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void InverterComm::updateCurrentRTCTime(sInverterRTCTime _t1, uint16_t _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void InverterComm::updateStatusBar(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void InverterComm::prepareUI_goodWe_GWT(eDecideInverter _t1, QByteArray _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void InverterComm::confirmNewSettings(uint8_t _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void InverterComm::confirmNewPowerFactor(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void InverterComm::confirmNewRTCTime(uint8_t _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
