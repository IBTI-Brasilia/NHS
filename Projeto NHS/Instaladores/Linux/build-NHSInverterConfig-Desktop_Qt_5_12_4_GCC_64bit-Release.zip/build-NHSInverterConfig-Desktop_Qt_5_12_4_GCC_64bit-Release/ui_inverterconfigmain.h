/********************************************************************************
** Form generated from reading UI file 'inverterconfigmain.ui'
**
** Created by: Qt User Interface Compiler version 5.12.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INVERTERCONFIGMAIN_H
#define UI_INVERTERCONFIGMAIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_InverterConfigMain
{
public:
    QAction *actionConnect;
    QAction *actionDisconnect;
    QAction *ScanPorts;
    QAction *actionSerialConfig;
    QWidget *centralWidget;
    QGridLayout *gridLayout_20;
    QTabWidget *tabWidget;
    QWidget *InfoTab;
    QGridLayout *gridLayout_38;
    QHBoxLayout *horizontalLayout_6;
    QGroupBox *groupBoxPV1;
    QGridLayout *gridLayout_8;
    QHBoxLayout *horizontalLayoutPV1;
    QGridLayout *gridLayout_5;
    QLabel *labelPV1Voltage;
    QLabel *labelPV1Current;
    QGridLayout *gridLayout_6;
    QLabel *labelPV1VoltageValue;
    QLabel *labelPV1CurrentValue;
    QGridLayout *gridLayout_7;
    QLabel *label_58;
    QLabel *label_59;
    QGroupBox *groupBoxPV2;
    QGridLayout *gridLayout_28;
    QHBoxLayout *horizontalLayoutPV2;
    QGridLayout *gridLayout_29;
    QLabel *labelPV1Voltage_2;
    QLabel *labelPV1Current_2;
    QGridLayout *gridLayout_30;
    QLabel *labelPV2VoltageValue;
    QLabel *labelPV2CurrentValue;
    QGridLayout *gridLayout_31;
    QLabel *label_60;
    QLabel *label_61;
    QHBoxLayout *horizontalLayoutPhase;
    QGroupBox *groupBoxPhaseL1;
    QGridLayout *gridLayout_4;
    QHBoxLayout *horizontalLayout;
    QGridLayout *gridLayout_2;
    QLabel *label_11;
    QLabel *label_8;
    QLabel *label_5;
    QGridLayout *gridLayout;
    QLabel *labelVoltageL1Value;
    QLabel *labelCurrentL1Value;
    QLabel *labelFrequencyL1Value;
    QGridLayout *gridLayout_3;
    QLabel *label_40;
    QLabel *label_46;
    QLabel *label_43;
    QGroupBox *groupBoxPhaseL2;
    QGridLayout *gridLayout_9;
    QHBoxLayout *horizontalLayout_3;
    QGridLayout *gridLayout_10;
    QLabel *label_12;
    QLabel *label_9;
    QLabel *label_6;
    QGridLayout *gridLayout_11;
    QLabel *labelVoltageL2Value;
    QLabel *labelCurrentL2Value;
    QLabel *labelFrequencyL2Value;
    QGridLayout *gridLayout_12;
    QLabel *label_41;
    QLabel *label_47;
    QLabel *label_44;
    QGroupBox *groupBoxPhaseL3;
    QGridLayout *gridLayout_18;
    QHBoxLayout *horizontalLayout_5;
    QGridLayout *gridLayout_19;
    QLabel *label_13;
    QLabel *label_10;
    QLabel *label_7;
    QGridLayout *gridLayout_26;
    QLabel *labelVoltageL3Value;
    QLabel *labelCurrentL3Value;
    QLabel *labelFrequencyL3Value;
    QGridLayout *gridLayout_27;
    QLabel *label_42;
    QLabel *label_48;
    QLabel *label_45;
    QHBoxLayout *horizontalLayoutStatus;
    QGroupBox *groupBoxInverterStatus;
    QGridLayout *gridLayout_16;
    QHBoxLayout *horizontalLayout_4;
    QGridLayout *gridLayout_13;
    QLabel *label_25;
    QLabel *label_24;
    QLabel *label_26;
    QGridLayout *gridLayout_14;
    QLabel *labelCountryCodeValue;
    QLabel *labelTemperatureValue;
    QLabel *labelWorkModeValue;
    QGroupBox *groupBoxGridStatusNetwork;
    QGridLayout *gridLayout_39;
    QGridLayout *gridLayout_45;
    QGridLayout *gridLayout_22;
    QLabel *label_29;
    QLabel *label_33;
    QGridLayout *gridLayout_23;
    QLabel *labelFeedingHoursValue;
    QLabel *labelFeedEnergyValue;
    QGridLayout *gridLayoutNetwork;
    QLabel *label_76;
    QLabel *label_77;
    QGroupBox *groupBoxInverterErrorStatus;
    QGridLayout *gridLayout_32;
    QHBoxLayout *horizontalLayout_7;
    QGridLayout *gridLayout_33;
    QLabel *label_28;
    QGridLayout *gridLayout_34;
    QLabel *labelErrorCodeValue;
    QWidget *ConfigTab;
    QGridLayout *gridLayout_21;
    QGroupBox *groupBoxRTC;
    QGridLayout *gridLayout_35;
    QPushButton *pushButtonSync;
    QLabel *labelDateTime;
    QGroupBox *groupBoxpowerFactor;
    QGridLayout *gridLayout_37;
    QGridLayout *gridLayout_17;
    QDoubleSpinBox *doubleSpinBoxPowerFactor;
    QLabel *labelStartDelayRange_2;
    QGridLayout *gridLayout_24;
    QComboBox *comboBoxPowerFactor;
    QPushButton *pushButtonConfPowerFactor;
    QGroupBox *groupBoxNewConfig;
    QGridLayout *gridLayout_15;
    QComboBox *comboBoxOutputVoltage;
    QLabel *labelStartDelay;
    QLineEdit *lineEditStartDelay;
    QLineEdit *lineEditReconnectTime;
    QLabel *labelStartDelayRange;
    QLabel *labelOutputVoltage;
    QPushButton *pushButtonConfigure;
    QLabel *labelRecconetTimeRange;
    QLabel *labelRecconetTime;
    QGroupBox *groupBoxDetailedConfig;
    QFormLayout *formLayout_3;
    QGridLayout *gridLayout_25;
    QLabel *labelStartDelay_2;
    QLabel *labelOutputVoltageValue;
    QLabel *labelReconnectTime_2;
    QLabel *labelOutputVoltage_2;
    QLabel *labelStartDelayValue;
    QLabel *labelReconnectTime;
    QGridLayout *gridLayout_42;
    QWidget *widget3;
    QFormLayout *formLayout_4;
    QLabel *labelPowerFactorCurveValue;
    QLabel *labelOverFrequencyValue;
    QLabel *labelUnderVoltageValue;
    QLabel *labelUnderFrequencyValue;
    QLabel *labelPowerFactorValue;
    QLabel *labelOverVoltageValue;
    QLabel *labelAntiIslandingValue;
    QWidget *widget2;
    QFormLayout *formLayout_5;
    QLabel *labelOverFrequency;
    QLabel *labelAntiIslanding;
    QLabel *labelUnderVoltage;
    QLabel *labelPowerFactor;
    QLabel *labelPowerFactorCurve;
    QLabel *labelUnderFrequency;
    QLabel *labelOverVoltage;
    QWidget *AboutTab;
    QGridLayout *gridLayout_40;
    QGridLayout *gridLayout_41;
    QLabel *labelNHSLogo;
    QFormLayout *layoutAboutLabels;
    QLabel *fwVersionLabel;
    QLineEdit *fwVersionLineEdit;
    QLabel *modelLabel;
    QLineEdit *modelLineEdit;
    QLabel *serialNumberLabel;
    QLineEdit *serialNumberLineEdit;
    QMenuBar *menuBar;
    QMenu *menuOp_es;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *InverterConfigMain)
    {
        if (InverterConfigMain->objectName().isEmpty())
            InverterConfigMain->setObjectName(QString::fromUtf8("InverterConfigMain"));
        InverterConfigMain->resize(612, 567);
        QSizePolicy sizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
        sizePolicy.setHorizontalStretch(255);
        sizePolicy.setVerticalStretch(255);
        sizePolicy.setHeightForWidth(InverterConfigMain->sizePolicy().hasHeightForWidth());
        InverterConfigMain->setSizePolicy(sizePolicy);
        InverterConfigMain->setMinimumSize(QSize(612, 567));
        InverterConfigMain->setMaximumSize(QSize(16777215, 16777215));
        QFont font;
        font.setPointSize(10);
        InverterConfigMain->setFont(font);
        actionConnect = new QAction(InverterConfigMain);
        actionConnect->setObjectName(QString::fromUtf8("actionConnect"));
        actionConnect->setFont(font);
        actionDisconnect = new QAction(InverterConfigMain);
        actionDisconnect->setObjectName(QString::fromUtf8("actionDisconnect"));
        actionDisconnect->setFont(font);
        ScanPorts = new QAction(InverterConfigMain);
        ScanPorts->setObjectName(QString::fromUtf8("ScanPorts"));
        ScanPorts->setFont(font);
        actionSerialConfig = new QAction(InverterConfigMain);
        actionSerialConfig->setObjectName(QString::fromUtf8("actionSerialConfig"));
        actionSerialConfig->setCheckable(false);
        actionSerialConfig->setChecked(false);
        actionSerialConfig->setEnabled(true);
        actionSerialConfig->setFont(font);
        centralWidget = new QWidget(InverterConfigMain);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        QSizePolicy sizePolicy1(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(centralWidget->sizePolicy().hasHeightForWidth());
        centralWidget->setSizePolicy(sizePolicy1);
        centralWidget->setMaximumSize(QSize(16777215, 16777215));
        gridLayout_20 = new QGridLayout(centralWidget);
        gridLayout_20->setSpacing(6);
        gridLayout_20->setContentsMargins(11, 11, 11, 11);
        gridLayout_20->setObjectName(QString::fromUtf8("gridLayout_20"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setEnabled(true);
        sizePolicy.setHeightForWidth(tabWidget->sizePolicy().hasHeightForWidth());
        tabWidget->setSizePolicy(sizePolicy);
        tabWidget->setFont(font);
        tabWidget->setLayoutDirection(Qt::LeftToRight);
        tabWidget->setTabShape(QTabWidget::Rounded);
        InfoTab = new QWidget();
        InfoTab->setObjectName(QString::fromUtf8("InfoTab"));
        sizePolicy.setHeightForWidth(InfoTab->sizePolicy().hasHeightForWidth());
        InfoTab->setSizePolicy(sizePolicy);
        gridLayout_38 = new QGridLayout(InfoTab);
        gridLayout_38->setSpacing(6);
        gridLayout_38->setContentsMargins(11, 11, 11, 11);
        gridLayout_38->setObjectName(QString::fromUtf8("gridLayout_38"));
        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setSizeConstraint(QLayout::SetMinAndMaxSize);
        groupBoxPV1 = new QGroupBox(InfoTab);
        groupBoxPV1->setObjectName(QString::fromUtf8("groupBoxPV1"));
        sizePolicy.setHeightForWidth(groupBoxPV1->sizePolicy().hasHeightForWidth());
        groupBoxPV1->setSizePolicy(sizePolicy);
        groupBoxPV1->setMinimumSize(QSize(155, 85));
        groupBoxPV1->setMaximumSize(QSize(16777215, 16777215));
        gridLayout_8 = new QGridLayout(groupBoxPV1);
        gridLayout_8->setSpacing(6);
        gridLayout_8->setContentsMargins(11, 11, 11, 11);
        gridLayout_8->setObjectName(QString::fromUtf8("gridLayout_8"));
        horizontalLayoutPV1 = new QHBoxLayout();
        horizontalLayoutPV1->setSpacing(6);
        horizontalLayoutPV1->setObjectName(QString::fromUtf8("horizontalLayoutPV1"));
        gridLayout_5 = new QGridLayout();
        gridLayout_5->setSpacing(6);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        labelPV1Voltage = new QLabel(groupBoxPV1);
        labelPV1Voltage->setObjectName(QString::fromUtf8("labelPV1Voltage"));
        labelPV1Voltage->setFont(font);
        labelPV1Voltage->setTextFormat(Qt::AutoText);
        labelPV1Voltage->setScaledContents(true);
        labelPV1Voltage->setWordWrap(false);

        gridLayout_5->addWidget(labelPV1Voltage, 0, 0, 1, 1);

        labelPV1Current = new QLabel(groupBoxPV1);
        labelPV1Current->setObjectName(QString::fromUtf8("labelPV1Current"));
        labelPV1Current->setFont(font);
        labelPV1Current->setTextFormat(Qt::AutoText);
        labelPV1Current->setScaledContents(true);
        labelPV1Current->setWordWrap(false);

        gridLayout_5->addWidget(labelPV1Current, 1, 0, 1, 1);


        horizontalLayoutPV1->addLayout(gridLayout_5);

        gridLayout_6 = new QGridLayout();
        gridLayout_6->setSpacing(6);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        labelPV1VoltageValue = new QLabel(groupBoxPV1);
        labelPV1VoltageValue->setObjectName(QString::fromUtf8("labelPV1VoltageValue"));
        labelPV1VoltageValue->setFont(font);
        labelPV1VoltageValue->setTextFormat(Qt::AutoText);
        labelPV1VoltageValue->setScaledContents(true);
        labelPV1VoltageValue->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelPV1VoltageValue->setWordWrap(false);

        gridLayout_6->addWidget(labelPV1VoltageValue, 0, 0, 1, 1);

        labelPV1CurrentValue = new QLabel(groupBoxPV1);
        labelPV1CurrentValue->setObjectName(QString::fromUtf8("labelPV1CurrentValue"));
        labelPV1CurrentValue->setFont(font);
        labelPV1CurrentValue->setTextFormat(Qt::AutoText);
        labelPV1CurrentValue->setScaledContents(true);
        labelPV1CurrentValue->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelPV1CurrentValue->setWordWrap(false);

        gridLayout_6->addWidget(labelPV1CurrentValue, 1, 0, 1, 1);


        horizontalLayoutPV1->addLayout(gridLayout_6);

        gridLayout_7 = new QGridLayout();
        gridLayout_7->setSpacing(6);
        gridLayout_7->setObjectName(QString::fromUtf8("gridLayout_7"));
        label_58 = new QLabel(groupBoxPV1);
        label_58->setObjectName(QString::fromUtf8("label_58"));
        label_58->setFont(font);
        label_58->setTextFormat(Qt::AutoText);
        label_58->setScaledContents(true);
        label_58->setWordWrap(false);

        gridLayout_7->addWidget(label_58, 0, 0, 1, 1);

        label_59 = new QLabel(groupBoxPV1);
        label_59->setObjectName(QString::fromUtf8("label_59"));
        label_59->setFont(font);
        label_59->setTextFormat(Qt::AutoText);
        label_59->setScaledContents(true);
        label_59->setWordWrap(false);

        gridLayout_7->addWidget(label_59, 1, 0, 1, 1);


        horizontalLayoutPV1->addLayout(gridLayout_7);


        gridLayout_8->addLayout(horizontalLayoutPV1, 0, 0, 1, 1);


        horizontalLayout_6->addWidget(groupBoxPV1);

        groupBoxPV2 = new QGroupBox(InfoTab);
        groupBoxPV2->setObjectName(QString::fromUtf8("groupBoxPV2"));
        sizePolicy.setHeightForWidth(groupBoxPV2->sizePolicy().hasHeightForWidth());
        groupBoxPV2->setSizePolicy(sizePolicy);
        groupBoxPV2->setMinimumSize(QSize(155, 85));
        groupBoxPV2->setMaximumSize(QSize(16777215, 16777215));
        gridLayout_28 = new QGridLayout(groupBoxPV2);
        gridLayout_28->setSpacing(6);
        gridLayout_28->setContentsMargins(11, 11, 11, 11);
        gridLayout_28->setObjectName(QString::fromUtf8("gridLayout_28"));
        horizontalLayoutPV2 = new QHBoxLayout();
        horizontalLayoutPV2->setSpacing(6);
        horizontalLayoutPV2->setObjectName(QString::fromUtf8("horizontalLayoutPV2"));
        gridLayout_29 = new QGridLayout();
        gridLayout_29->setSpacing(6);
        gridLayout_29->setObjectName(QString::fromUtf8("gridLayout_29"));
        labelPV1Voltage_2 = new QLabel(groupBoxPV2);
        labelPV1Voltage_2->setObjectName(QString::fromUtf8("labelPV1Voltage_2"));
        labelPV1Voltage_2->setFont(font);
        labelPV1Voltage_2->setTextFormat(Qt::AutoText);
        labelPV1Voltage_2->setScaledContents(true);
        labelPV1Voltage_2->setWordWrap(false);

        gridLayout_29->addWidget(labelPV1Voltage_2, 0, 0, 1, 1);

        labelPV1Current_2 = new QLabel(groupBoxPV2);
        labelPV1Current_2->setObjectName(QString::fromUtf8("labelPV1Current_2"));
        labelPV1Current_2->setFont(font);
        labelPV1Current_2->setTextFormat(Qt::AutoText);
        labelPV1Current_2->setScaledContents(true);
        labelPV1Current_2->setWordWrap(false);

        gridLayout_29->addWidget(labelPV1Current_2, 1, 0, 1, 1);


        horizontalLayoutPV2->addLayout(gridLayout_29);

        gridLayout_30 = new QGridLayout();
        gridLayout_30->setSpacing(6);
        gridLayout_30->setObjectName(QString::fromUtf8("gridLayout_30"));
        labelPV2VoltageValue = new QLabel(groupBoxPV2);
        labelPV2VoltageValue->setObjectName(QString::fromUtf8("labelPV2VoltageValue"));
        labelPV2VoltageValue->setFont(font);
        labelPV2VoltageValue->setTextFormat(Qt::AutoText);
        labelPV2VoltageValue->setScaledContents(true);
        labelPV2VoltageValue->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelPV2VoltageValue->setWordWrap(false);

        gridLayout_30->addWidget(labelPV2VoltageValue, 0, 0, 1, 1);

        labelPV2CurrentValue = new QLabel(groupBoxPV2);
        labelPV2CurrentValue->setObjectName(QString::fromUtf8("labelPV2CurrentValue"));
        labelPV2CurrentValue->setFont(font);
        labelPV2CurrentValue->setTextFormat(Qt::AutoText);
        labelPV2CurrentValue->setScaledContents(true);
        labelPV2CurrentValue->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelPV2CurrentValue->setWordWrap(false);

        gridLayout_30->addWidget(labelPV2CurrentValue, 1, 0, 1, 1);


        horizontalLayoutPV2->addLayout(gridLayout_30);

        gridLayout_31 = new QGridLayout();
        gridLayout_31->setSpacing(6);
        gridLayout_31->setObjectName(QString::fromUtf8("gridLayout_31"));
        label_60 = new QLabel(groupBoxPV2);
        label_60->setObjectName(QString::fromUtf8("label_60"));
        label_60->setFont(font);
        label_60->setTextFormat(Qt::AutoText);
        label_60->setScaledContents(true);
        label_60->setWordWrap(false);

        gridLayout_31->addWidget(label_60, 0, 0, 1, 1);

        label_61 = new QLabel(groupBoxPV2);
        label_61->setObjectName(QString::fromUtf8("label_61"));
        label_61->setFont(font);
        label_61->setTextFormat(Qt::AutoText);
        label_61->setScaledContents(true);
        label_61->setWordWrap(false);

        gridLayout_31->addWidget(label_61, 1, 0, 1, 1);


        horizontalLayoutPV2->addLayout(gridLayout_31);


        gridLayout_28->addLayout(horizontalLayoutPV2, 0, 0, 1, 1);


        horizontalLayout_6->addWidget(groupBoxPV2);


        gridLayout_38->addLayout(horizontalLayout_6, 0, 0, 1, 1);

        horizontalLayoutPhase = new QHBoxLayout();
        horizontalLayoutPhase->setSpacing(6);
        horizontalLayoutPhase->setObjectName(QString::fromUtf8("horizontalLayoutPhase"));
        horizontalLayoutPhase->setSizeConstraint(QLayout::SetMinAndMaxSize);
        groupBoxPhaseL1 = new QGroupBox(InfoTab);
        groupBoxPhaseL1->setObjectName(QString::fromUtf8("groupBoxPhaseL1"));
        sizePolicy.setHeightForWidth(groupBoxPhaseL1->sizePolicy().hasHeightForWidth());
        groupBoxPhaseL1->setSizePolicy(sizePolicy);
        groupBoxPhaseL1->setMinimumSize(QSize(155, 110));
        groupBoxPhaseL1->setMaximumSize(QSize(16777215, 16777215));
        gridLayout_4 = new QGridLayout(groupBoxPhaseL1);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        gridLayout_2 = new QGridLayout();
        gridLayout_2->setSpacing(6);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label_11 = new QLabel(groupBoxPhaseL1);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        sizePolicy1.setHeightForWidth(label_11->sizePolicy().hasHeightForWidth());
        label_11->setSizePolicy(sizePolicy1);
        label_11->setMinimumSize(QSize(68, 17));
        label_11->setMaximumSize(QSize(68, 17));
        label_11->setFont(font);
        label_11->setTextFormat(Qt::AutoText);
        label_11->setScaledContents(true);
        label_11->setWordWrap(false);

        gridLayout_2->addWidget(label_11, 2, 0, 1, 1);

        label_8 = new QLabel(groupBoxPhaseL1);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        sizePolicy1.setHeightForWidth(label_8->sizePolicy().hasHeightForWidth());
        label_8->setSizePolicy(sizePolicy1);
        label_8->setMinimumSize(QSize(68, 17));
        label_8->setMaximumSize(QSize(68, 17));
        label_8->setFont(font);
        label_8->setTextFormat(Qt::AutoText);
        label_8->setScaledContents(true);
        label_8->setWordWrap(false);

        gridLayout_2->addWidget(label_8, 1, 0, 1, 1);

        label_5 = new QLabel(groupBoxPhaseL1);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        sizePolicy1.setHeightForWidth(label_5->sizePolicy().hasHeightForWidth());
        label_5->setSizePolicy(sizePolicy1);
        label_5->setMinimumSize(QSize(68, 17));
        label_5->setMaximumSize(QSize(68, 17));
        label_5->setFont(font);
        label_5->setTextFormat(Qt::AutoText);
        label_5->setScaledContents(true);
        label_5->setWordWrap(false);

        gridLayout_2->addWidget(label_5, 0, 0, 1, 1);


        horizontalLayout->addLayout(gridLayout_2);

        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        labelVoltageL1Value = new QLabel(groupBoxPhaseL1);
        labelVoltageL1Value->setObjectName(QString::fromUtf8("labelVoltageL1Value"));
        sizePolicy1.setHeightForWidth(labelVoltageL1Value->sizePolicy().hasHeightForWidth());
        labelVoltageL1Value->setSizePolicy(sizePolicy1);
        labelVoltageL1Value->setMinimumSize(QSize(35, 17));
        labelVoltageL1Value->setFont(font);
        labelVoltageL1Value->setTextFormat(Qt::AutoText);
        labelVoltageL1Value->setScaledContents(true);
        labelVoltageL1Value->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelVoltageL1Value->setWordWrap(false);

        gridLayout->addWidget(labelVoltageL1Value, 0, 0, 1, 1);

        labelCurrentL1Value = new QLabel(groupBoxPhaseL1);
        labelCurrentL1Value->setObjectName(QString::fromUtf8("labelCurrentL1Value"));
        sizePolicy1.setHeightForWidth(labelCurrentL1Value->sizePolicy().hasHeightForWidth());
        labelCurrentL1Value->setSizePolicy(sizePolicy1);
        labelCurrentL1Value->setMinimumSize(QSize(35, 17));
        labelCurrentL1Value->setFont(font);
        labelCurrentL1Value->setTextFormat(Qt::AutoText);
        labelCurrentL1Value->setScaledContents(true);
        labelCurrentL1Value->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelCurrentL1Value->setWordWrap(false);

        gridLayout->addWidget(labelCurrentL1Value, 1, 0, 1, 1);

        labelFrequencyL1Value = new QLabel(groupBoxPhaseL1);
        labelFrequencyL1Value->setObjectName(QString::fromUtf8("labelFrequencyL1Value"));
        sizePolicy1.setHeightForWidth(labelFrequencyL1Value->sizePolicy().hasHeightForWidth());
        labelFrequencyL1Value->setSizePolicy(sizePolicy1);
        labelFrequencyL1Value->setMinimumSize(QSize(35, 17));
        labelFrequencyL1Value->setFont(font);
        labelFrequencyL1Value->setTextFormat(Qt::AutoText);
        labelFrequencyL1Value->setScaledContents(true);
        labelFrequencyL1Value->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelFrequencyL1Value->setWordWrap(false);

        gridLayout->addWidget(labelFrequencyL1Value, 2, 0, 1, 1);


        horizontalLayout->addLayout(gridLayout);

        gridLayout_3 = new QGridLayout();
        gridLayout_3->setSpacing(6);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        label_40 = new QLabel(groupBoxPhaseL1);
        label_40->setObjectName(QString::fromUtf8("label_40"));
        sizePolicy1.setHeightForWidth(label_40->sizePolicy().hasHeightForWidth());
        label_40->setSizePolicy(sizePolicy1);
        label_40->setMinimumSize(QSize(14, 17));
        label_40->setMaximumSize(QSize(14, 17));
        label_40->setFont(font);
        label_40->setTextFormat(Qt::AutoText);
        label_40->setScaledContents(true);
        label_40->setWordWrap(false);

        gridLayout_3->addWidget(label_40, 0, 0, 1, 1);

        label_46 = new QLabel(groupBoxPhaseL1);
        label_46->setObjectName(QString::fromUtf8("label_46"));
        sizePolicy1.setHeightForWidth(label_46->sizePolicy().hasHeightForWidth());
        label_46->setSizePolicy(sizePolicy1);
        label_46->setMinimumSize(QSize(14, 17));
        label_46->setMaximumSize(QSize(14, 17));
        label_46->setFont(font);
        label_46->setTextFormat(Qt::AutoText);
        label_46->setScaledContents(true);
        label_46->setWordWrap(false);

        gridLayout_3->addWidget(label_46, 2, 0, 1, 1);

        label_43 = new QLabel(groupBoxPhaseL1);
        label_43->setObjectName(QString::fromUtf8("label_43"));
        sizePolicy1.setHeightForWidth(label_43->sizePolicy().hasHeightForWidth());
        label_43->setSizePolicy(sizePolicy1);
        label_43->setMinimumSize(QSize(14, 17));
        label_43->setMaximumSize(QSize(14, 17));
        label_43->setFont(font);
        label_43->setTextFormat(Qt::AutoText);
        label_43->setScaledContents(true);
        label_43->setWordWrap(false);

        gridLayout_3->addWidget(label_43, 1, 0, 1, 1);


        horizontalLayout->addLayout(gridLayout_3);


        gridLayout_4->addLayout(horizontalLayout, 0, 0, 1, 1);


        horizontalLayoutPhase->addWidget(groupBoxPhaseL1);

        groupBoxPhaseL2 = new QGroupBox(InfoTab);
        groupBoxPhaseL2->setObjectName(QString::fromUtf8("groupBoxPhaseL2"));
        sizePolicy.setHeightForWidth(groupBoxPhaseL2->sizePolicy().hasHeightForWidth());
        groupBoxPhaseL2->setSizePolicy(sizePolicy);
        groupBoxPhaseL2->setMinimumSize(QSize(155, 110));
        groupBoxPhaseL2->setMaximumSize(QSize(16777215, 16777215));
        gridLayout_9 = new QGridLayout(groupBoxPhaseL2);
        gridLayout_9->setSpacing(6);
        gridLayout_9->setContentsMargins(11, 11, 11, 11);
        gridLayout_9->setObjectName(QString::fromUtf8("gridLayout_9"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        gridLayout_10 = new QGridLayout();
        gridLayout_10->setSpacing(6);
        gridLayout_10->setObjectName(QString::fromUtf8("gridLayout_10"));
        label_12 = new QLabel(groupBoxPhaseL2);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        sizePolicy1.setHeightForWidth(label_12->sizePolicy().hasHeightForWidth());
        label_12->setSizePolicy(sizePolicy1);
        label_12->setMinimumSize(QSize(68, 17));
        label_12->setMaximumSize(QSize(68, 17));
        label_12->setFont(font);
        label_12->setTextFormat(Qt::AutoText);
        label_12->setScaledContents(true);
        label_12->setWordWrap(false);

        gridLayout_10->addWidget(label_12, 2, 0, 1, 1);

        label_9 = new QLabel(groupBoxPhaseL2);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        sizePolicy1.setHeightForWidth(label_9->sizePolicy().hasHeightForWidth());
        label_9->setSizePolicy(sizePolicy1);
        label_9->setMinimumSize(QSize(68, 17));
        label_9->setMaximumSize(QSize(68, 17));
        label_9->setFont(font);
        label_9->setTextFormat(Qt::AutoText);
        label_9->setScaledContents(true);
        label_9->setWordWrap(false);

        gridLayout_10->addWidget(label_9, 1, 0, 1, 1);

        label_6 = new QLabel(groupBoxPhaseL2);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        sizePolicy1.setHeightForWidth(label_6->sizePolicy().hasHeightForWidth());
        label_6->setSizePolicy(sizePolicy1);
        label_6->setMinimumSize(QSize(68, 17));
        label_6->setMaximumSize(QSize(68, 17));
        label_6->setFont(font);
        label_6->setTextFormat(Qt::AutoText);
        label_6->setScaledContents(true);
        label_6->setWordWrap(false);

        gridLayout_10->addWidget(label_6, 0, 0, 1, 1);


        horizontalLayout_3->addLayout(gridLayout_10);

        gridLayout_11 = new QGridLayout();
        gridLayout_11->setSpacing(6);
        gridLayout_11->setObjectName(QString::fromUtf8("gridLayout_11"));
        labelVoltageL2Value = new QLabel(groupBoxPhaseL2);
        labelVoltageL2Value->setObjectName(QString::fromUtf8("labelVoltageL2Value"));
        sizePolicy1.setHeightForWidth(labelVoltageL2Value->sizePolicy().hasHeightForWidth());
        labelVoltageL2Value->setSizePolicy(sizePolicy1);
        labelVoltageL2Value->setMinimumSize(QSize(35, 17));
        labelVoltageL2Value->setFont(font);
        labelVoltageL2Value->setTextFormat(Qt::AutoText);
        labelVoltageL2Value->setScaledContents(true);
        labelVoltageL2Value->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelVoltageL2Value->setWordWrap(false);

        gridLayout_11->addWidget(labelVoltageL2Value, 0, 0, 1, 1);

        labelCurrentL2Value = new QLabel(groupBoxPhaseL2);
        labelCurrentL2Value->setObjectName(QString::fromUtf8("labelCurrentL2Value"));
        sizePolicy1.setHeightForWidth(labelCurrentL2Value->sizePolicy().hasHeightForWidth());
        labelCurrentL2Value->setSizePolicy(sizePolicy1);
        labelCurrentL2Value->setMinimumSize(QSize(35, 17));
        labelCurrentL2Value->setFont(font);
        labelCurrentL2Value->setTextFormat(Qt::AutoText);
        labelCurrentL2Value->setScaledContents(true);
        labelCurrentL2Value->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelCurrentL2Value->setWordWrap(false);

        gridLayout_11->addWidget(labelCurrentL2Value, 1, 0, 1, 1);

        labelFrequencyL2Value = new QLabel(groupBoxPhaseL2);
        labelFrequencyL2Value->setObjectName(QString::fromUtf8("labelFrequencyL2Value"));
        sizePolicy1.setHeightForWidth(labelFrequencyL2Value->sizePolicy().hasHeightForWidth());
        labelFrequencyL2Value->setSizePolicy(sizePolicy1);
        labelFrequencyL2Value->setMinimumSize(QSize(35, 17));
        labelFrequencyL2Value->setFont(font);
        labelFrequencyL2Value->setTextFormat(Qt::AutoText);
        labelFrequencyL2Value->setScaledContents(true);
        labelFrequencyL2Value->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelFrequencyL2Value->setWordWrap(false);

        gridLayout_11->addWidget(labelFrequencyL2Value, 2, 0, 1, 1);


        horizontalLayout_3->addLayout(gridLayout_11);

        gridLayout_12 = new QGridLayout();
        gridLayout_12->setSpacing(6);
        gridLayout_12->setObjectName(QString::fromUtf8("gridLayout_12"));
        label_41 = new QLabel(groupBoxPhaseL2);
        label_41->setObjectName(QString::fromUtf8("label_41"));
        sizePolicy1.setHeightForWidth(label_41->sizePolicy().hasHeightForWidth());
        label_41->setSizePolicy(sizePolicy1);
        label_41->setMinimumSize(QSize(14, 17));
        label_41->setMaximumSize(QSize(14, 17));
        label_41->setFont(font);
        label_41->setTextFormat(Qt::AutoText);
        label_41->setScaledContents(true);
        label_41->setWordWrap(false);

        gridLayout_12->addWidget(label_41, 0, 0, 1, 1);

        label_47 = new QLabel(groupBoxPhaseL2);
        label_47->setObjectName(QString::fromUtf8("label_47"));
        sizePolicy1.setHeightForWidth(label_47->sizePolicy().hasHeightForWidth());
        label_47->setSizePolicy(sizePolicy1);
        label_47->setMinimumSize(QSize(14, 17));
        label_47->setMaximumSize(QSize(14, 17));
        label_47->setFont(font);
        label_47->setTextFormat(Qt::AutoText);
        label_47->setScaledContents(true);
        label_47->setWordWrap(false);

        gridLayout_12->addWidget(label_47, 2, 0, 1, 1);

        label_44 = new QLabel(groupBoxPhaseL2);
        label_44->setObjectName(QString::fromUtf8("label_44"));
        sizePolicy1.setHeightForWidth(label_44->sizePolicy().hasHeightForWidth());
        label_44->setSizePolicy(sizePolicy1);
        label_44->setMinimumSize(QSize(14, 17));
        label_44->setMaximumSize(QSize(14, 17));
        label_44->setFont(font);
        label_44->setTextFormat(Qt::AutoText);
        label_44->setScaledContents(true);
        label_44->setWordWrap(false);

        gridLayout_12->addWidget(label_44, 1, 0, 1, 1);


        horizontalLayout_3->addLayout(gridLayout_12);


        gridLayout_9->addLayout(horizontalLayout_3, 0, 0, 1, 1);


        horizontalLayoutPhase->addWidget(groupBoxPhaseL2);

        groupBoxPhaseL3 = new QGroupBox(InfoTab);
        groupBoxPhaseL3->setObjectName(QString::fromUtf8("groupBoxPhaseL3"));
        sizePolicy.setHeightForWidth(groupBoxPhaseL3->sizePolicy().hasHeightForWidth());
        groupBoxPhaseL3->setSizePolicy(sizePolicy);
        groupBoxPhaseL3->setMinimumSize(QSize(155, 110));
        groupBoxPhaseL3->setMaximumSize(QSize(16777215, 110));
        gridLayout_18 = new QGridLayout(groupBoxPhaseL3);
        gridLayout_18->setSpacing(6);
        gridLayout_18->setContentsMargins(11, 11, 11, 11);
        gridLayout_18->setObjectName(QString::fromUtf8("gridLayout_18"));
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        gridLayout_19 = new QGridLayout();
        gridLayout_19->setSpacing(6);
        gridLayout_19->setObjectName(QString::fromUtf8("gridLayout_19"));
        label_13 = new QLabel(groupBoxPhaseL3);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        sizePolicy1.setHeightForWidth(label_13->sizePolicy().hasHeightForWidth());
        label_13->setSizePolicy(sizePolicy1);
        label_13->setMinimumSize(QSize(68, 17));
        label_13->setMaximumSize(QSize(68, 17));
        label_13->setFont(font);
        label_13->setTextFormat(Qt::AutoText);
        label_13->setScaledContents(true);
        label_13->setWordWrap(false);

        gridLayout_19->addWidget(label_13, 2, 0, 1, 1);

        label_10 = new QLabel(groupBoxPhaseL3);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        sizePolicy1.setHeightForWidth(label_10->sizePolicy().hasHeightForWidth());
        label_10->setSizePolicy(sizePolicy1);
        label_10->setMinimumSize(QSize(68, 17));
        label_10->setMaximumSize(QSize(68, 17));
        label_10->setFont(font);
        label_10->setTextFormat(Qt::AutoText);
        label_10->setScaledContents(true);
        label_10->setWordWrap(false);

        gridLayout_19->addWidget(label_10, 1, 0, 1, 1);

        label_7 = new QLabel(groupBoxPhaseL3);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        sizePolicy1.setHeightForWidth(label_7->sizePolicy().hasHeightForWidth());
        label_7->setSizePolicy(sizePolicy1);
        label_7->setMinimumSize(QSize(68, 17));
        label_7->setMaximumSize(QSize(68, 17));
        label_7->setFont(font);
        label_7->setTextFormat(Qt::AutoText);
        label_7->setScaledContents(true);
        label_7->setWordWrap(false);

        gridLayout_19->addWidget(label_7, 0, 0, 1, 1);


        horizontalLayout_5->addLayout(gridLayout_19);

        gridLayout_26 = new QGridLayout();
        gridLayout_26->setSpacing(6);
        gridLayout_26->setObjectName(QString::fromUtf8("gridLayout_26"));
        labelVoltageL3Value = new QLabel(groupBoxPhaseL3);
        labelVoltageL3Value->setObjectName(QString::fromUtf8("labelVoltageL3Value"));
        sizePolicy1.setHeightForWidth(labelVoltageL3Value->sizePolicy().hasHeightForWidth());
        labelVoltageL3Value->setSizePolicy(sizePolicy1);
        labelVoltageL3Value->setMinimumSize(QSize(35, 17));
        labelVoltageL3Value->setFont(font);
        labelVoltageL3Value->setTextFormat(Qt::AutoText);
        labelVoltageL3Value->setScaledContents(true);
        labelVoltageL3Value->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelVoltageL3Value->setWordWrap(false);

        gridLayout_26->addWidget(labelVoltageL3Value, 0, 0, 1, 1);

        labelCurrentL3Value = new QLabel(groupBoxPhaseL3);
        labelCurrentL3Value->setObjectName(QString::fromUtf8("labelCurrentL3Value"));
        sizePolicy1.setHeightForWidth(labelCurrentL3Value->sizePolicy().hasHeightForWidth());
        labelCurrentL3Value->setSizePolicy(sizePolicy1);
        labelCurrentL3Value->setMinimumSize(QSize(35, 17));
        labelCurrentL3Value->setFont(font);
        labelCurrentL3Value->setTextFormat(Qt::AutoText);
        labelCurrentL3Value->setScaledContents(true);
        labelCurrentL3Value->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelCurrentL3Value->setWordWrap(false);

        gridLayout_26->addWidget(labelCurrentL3Value, 1, 0, 1, 1);

        labelFrequencyL3Value = new QLabel(groupBoxPhaseL3);
        labelFrequencyL3Value->setObjectName(QString::fromUtf8("labelFrequencyL3Value"));
        sizePolicy1.setHeightForWidth(labelFrequencyL3Value->sizePolicy().hasHeightForWidth());
        labelFrequencyL3Value->setSizePolicy(sizePolicy1);
        labelFrequencyL3Value->setMinimumSize(QSize(35, 17));
        labelFrequencyL3Value->setFont(font);
        labelFrequencyL3Value->setTextFormat(Qt::AutoText);
        labelFrequencyL3Value->setScaledContents(true);
        labelFrequencyL3Value->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelFrequencyL3Value->setWordWrap(false);

        gridLayout_26->addWidget(labelFrequencyL3Value, 2, 0, 1, 1);


        horizontalLayout_5->addLayout(gridLayout_26);

        gridLayout_27 = new QGridLayout();
        gridLayout_27->setSpacing(6);
        gridLayout_27->setObjectName(QString::fromUtf8("gridLayout_27"));
        label_42 = new QLabel(groupBoxPhaseL3);
        label_42->setObjectName(QString::fromUtf8("label_42"));
        sizePolicy1.setHeightForWidth(label_42->sizePolicy().hasHeightForWidth());
        label_42->setSizePolicy(sizePolicy1);
        label_42->setMinimumSize(QSize(14, 17));
        label_42->setMaximumSize(QSize(14, 17));
        label_42->setFont(font);
        label_42->setTextFormat(Qt::AutoText);
        label_42->setScaledContents(true);
        label_42->setWordWrap(false);

        gridLayout_27->addWidget(label_42, 0, 0, 1, 1);

        label_48 = new QLabel(groupBoxPhaseL3);
        label_48->setObjectName(QString::fromUtf8("label_48"));
        sizePolicy1.setHeightForWidth(label_48->sizePolicy().hasHeightForWidth());
        label_48->setSizePolicy(sizePolicy1);
        label_48->setMinimumSize(QSize(14, 17));
        label_48->setMaximumSize(QSize(14, 17));
        label_48->setFont(font);
        label_48->setTextFormat(Qt::AutoText);
        label_48->setScaledContents(true);
        label_48->setWordWrap(false);

        gridLayout_27->addWidget(label_48, 2, 0, 1, 1);

        label_45 = new QLabel(groupBoxPhaseL3);
        label_45->setObjectName(QString::fromUtf8("label_45"));
        sizePolicy1.setHeightForWidth(label_45->sizePolicy().hasHeightForWidth());
        label_45->setSizePolicy(sizePolicy1);
        label_45->setMinimumSize(QSize(14, 17));
        label_45->setMaximumSize(QSize(14, 17));
        label_45->setFont(font);
        label_45->setTextFormat(Qt::AutoText);
        label_45->setScaledContents(true);
        label_45->setWordWrap(false);

        gridLayout_27->addWidget(label_45, 1, 0, 1, 1);


        horizontalLayout_5->addLayout(gridLayout_27);


        gridLayout_18->addLayout(horizontalLayout_5, 0, 0, 1, 1);


        horizontalLayoutPhase->addWidget(groupBoxPhaseL3);


        gridLayout_38->addLayout(horizontalLayoutPhase, 1, 0, 1, 1);

        horizontalLayoutStatus = new QHBoxLayout();
        horizontalLayoutStatus->setSpacing(6);
        horizontalLayoutStatus->setObjectName(QString::fromUtf8("horizontalLayoutStatus"));
        horizontalLayoutStatus->setSizeConstraint(QLayout::SetMinAndMaxSize);
        groupBoxInverterStatus = new QGroupBox(InfoTab);
        groupBoxInverterStatus->setObjectName(QString::fromUtf8("groupBoxInverterStatus"));
        sizePolicy.setHeightForWidth(groupBoxInverterStatus->sizePolicy().hasHeightForWidth());
        groupBoxInverterStatus->setSizePolicy(sizePolicy);
        groupBoxInverterStatus->setMinimumSize(QSize(155, 110));
        groupBoxInverterStatus->setMaximumSize(QSize(16777215, 16777215));
        gridLayout_16 = new QGridLayout(groupBoxInverterStatus);
        gridLayout_16->setSpacing(6);
        gridLayout_16->setContentsMargins(11, 11, 11, 11);
        gridLayout_16->setObjectName(QString::fromUtf8("gridLayout_16"));
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        gridLayout_13 = new QGridLayout();
        gridLayout_13->setSpacing(6);
        gridLayout_13->setObjectName(QString::fromUtf8("gridLayout_13"));
        label_25 = new QLabel(groupBoxInverterStatus);
        label_25->setObjectName(QString::fromUtf8("label_25"));
        label_25->setFont(font);
        label_25->setTextFormat(Qt::AutoText);
        label_25->setScaledContents(true);
        label_25->setWordWrap(false);

        gridLayout_13->addWidget(label_25, 1, 0, 1, 1);

        label_24 = new QLabel(groupBoxInverterStatus);
        label_24->setObjectName(QString::fromUtf8("label_24"));
        label_24->setFont(font);
        label_24->setTextFormat(Qt::AutoText);
        label_24->setScaledContents(true);
        label_24->setWordWrap(false);

        gridLayout_13->addWidget(label_24, 0, 0, 1, 1);

        label_26 = new QLabel(groupBoxInverterStatus);
        label_26->setObjectName(QString::fromUtf8("label_26"));
        label_26->setFont(font);
        label_26->setTextFormat(Qt::AutoText);
        label_26->setScaledContents(true);
        label_26->setWordWrap(false);

        gridLayout_13->addWidget(label_26, 2, 0, 1, 1);


        horizontalLayout_4->addLayout(gridLayout_13);

        gridLayout_14 = new QGridLayout();
        gridLayout_14->setSpacing(6);
        gridLayout_14->setObjectName(QString::fromUtf8("gridLayout_14"));
        labelCountryCodeValue = new QLabel(groupBoxInverterStatus);
        labelCountryCodeValue->setObjectName(QString::fromUtf8("labelCountryCodeValue"));
        labelCountryCodeValue->setFont(font);
        labelCountryCodeValue->setTextFormat(Qt::AutoText);
        labelCountryCodeValue->setScaledContents(true);
        labelCountryCodeValue->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelCountryCodeValue->setWordWrap(false);

        gridLayout_14->addWidget(labelCountryCodeValue, 2, 0, 1, 1);

        labelTemperatureValue = new QLabel(groupBoxInverterStatus);
        labelTemperatureValue->setObjectName(QString::fromUtf8("labelTemperatureValue"));
        labelTemperatureValue->setFont(font);
        labelTemperatureValue->setTextFormat(Qt::AutoText);
        labelTemperatureValue->setScaledContents(true);
        labelTemperatureValue->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelTemperatureValue->setWordWrap(false);

        gridLayout_14->addWidget(labelTemperatureValue, 1, 0, 1, 1);

        labelWorkModeValue = new QLabel(groupBoxInverterStatus);
        labelWorkModeValue->setObjectName(QString::fromUtf8("labelWorkModeValue"));
        labelWorkModeValue->setFont(font);
        labelWorkModeValue->setTextFormat(Qt::AutoText);
        labelWorkModeValue->setScaledContents(true);
        labelWorkModeValue->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelWorkModeValue->setWordWrap(false);

        gridLayout_14->addWidget(labelWorkModeValue, 0, 0, 1, 1);


        horizontalLayout_4->addLayout(gridLayout_14);


        gridLayout_16->addLayout(horizontalLayout_4, 0, 0, 1, 1);


        horizontalLayoutStatus->addWidget(groupBoxInverterStatus);

        groupBoxGridStatusNetwork = new QGroupBox(InfoTab);
        groupBoxGridStatusNetwork->setObjectName(QString::fromUtf8("groupBoxGridStatusNetwork"));
        sizePolicy.setHeightForWidth(groupBoxGridStatusNetwork->sizePolicy().hasHeightForWidth());
        groupBoxGridStatusNetwork->setSizePolicy(sizePolicy);
        groupBoxGridStatusNetwork->setMinimumSize(QSize(155, 110));
        groupBoxGridStatusNetwork->setMaximumSize(QSize(16777215, 16777215));
        gridLayout_39 = new QGridLayout(groupBoxGridStatusNetwork);
        gridLayout_39->setSpacing(6);
        gridLayout_39->setContentsMargins(11, 11, 11, 11);
        gridLayout_39->setObjectName(QString::fromUtf8("gridLayout_39"));
        gridLayout_45 = new QGridLayout();
        gridLayout_45->setSpacing(6);
        gridLayout_45->setObjectName(QString::fromUtf8("gridLayout_45"));
        gridLayout_45->setContentsMargins(6, -1, 0, -1);
        gridLayout_22 = new QGridLayout();
        gridLayout_22->setSpacing(6);
        gridLayout_22->setObjectName(QString::fromUtf8("gridLayout_22"));
        label_29 = new QLabel(groupBoxGridStatusNetwork);
        label_29->setObjectName(QString::fromUtf8("label_29"));
        sizePolicy1.setHeightForWidth(label_29->sizePolicy().hasHeightForWidth());
        label_29->setSizePolicy(sizePolicy1);
        label_29->setMinimumSize(QSize(46, 16));
        label_29->setMaximumSize(QSize(46, 16));
        label_29->setFont(font);
        label_29->setTextFormat(Qt::AutoText);
        label_29->setScaledContents(true);
        label_29->setWordWrap(false);

        gridLayout_22->addWidget(label_29, 0, 0, 1, 1);

        label_33 = new QLabel(groupBoxGridStatusNetwork);
        label_33->setObjectName(QString::fromUtf8("label_33"));
        sizePolicy1.setHeightForWidth(label_33->sizePolicy().hasHeightForWidth());
        label_33->setSizePolicy(sizePolicy1);
        label_33->setMinimumSize(QSize(46, 16));
        label_33->setMaximumSize(QSize(46, 16));
        label_33->setFont(font);
        label_33->setTextFormat(Qt::AutoText);
        label_33->setScaledContents(true);
        label_33->setWordWrap(false);

        gridLayout_22->addWidget(label_33, 1, 0, 1, 1);


        gridLayout_45->addLayout(gridLayout_22, 0, 0, 1, 1);

        gridLayout_23 = new QGridLayout();
        gridLayout_23->setSpacing(6);
        gridLayout_23->setObjectName(QString::fromUtf8("gridLayout_23"));
        labelFeedingHoursValue = new QLabel(groupBoxGridStatusNetwork);
        labelFeedingHoursValue->setObjectName(QString::fromUtf8("labelFeedingHoursValue"));
        sizePolicy1.setHeightForWidth(labelFeedingHoursValue->sizePolicy().hasHeightForWidth());
        labelFeedingHoursValue->setSizePolicy(sizePolicy1);
        labelFeedingHoursValue->setMinimumSize(QSize(56, 16));
        labelFeedingHoursValue->setMaximumSize(QSize(56, 16));
        labelFeedingHoursValue->setFont(font);
        labelFeedingHoursValue->setTextFormat(Qt::AutoText);
        labelFeedingHoursValue->setScaledContents(true);
        labelFeedingHoursValue->setAlignment(Qt::AlignCenter);
        labelFeedingHoursValue->setWordWrap(false);

        gridLayout_23->addWidget(labelFeedingHoursValue, 0, 0, 1, 1);

        labelFeedEnergyValue = new QLabel(groupBoxGridStatusNetwork);
        labelFeedEnergyValue->setObjectName(QString::fromUtf8("labelFeedEnergyValue"));
        sizePolicy1.setHeightForWidth(labelFeedEnergyValue->sizePolicy().hasHeightForWidth());
        labelFeedEnergyValue->setSizePolicy(sizePolicy1);
        labelFeedEnergyValue->setMinimumSize(QSize(56, 16));
        labelFeedEnergyValue->setMaximumSize(QSize(56, 16));
        labelFeedEnergyValue->setFont(font);
        labelFeedEnergyValue->setLayoutDirection(Qt::LeftToRight);
        labelFeedEnergyValue->setTextFormat(Qt::AutoText);
        labelFeedEnergyValue->setScaledContents(true);
        labelFeedEnergyValue->setAlignment(Qt::AlignCenter);
        labelFeedEnergyValue->setWordWrap(false);

        gridLayout_23->addWidget(labelFeedEnergyValue, 1, 0, 1, 1);


        gridLayout_45->addLayout(gridLayout_23, 0, 1, 1, 1);

        gridLayoutNetwork = new QGridLayout();
        gridLayoutNetwork->setSpacing(6);
        gridLayoutNetwork->setObjectName(QString::fromUtf8("gridLayoutNetwork"));
        label_76 = new QLabel(groupBoxGridStatusNetwork);
        label_76->setObjectName(QString::fromUtf8("label_76"));
        sizePolicy1.setHeightForWidth(label_76->sizePolicy().hasHeightForWidth());
        label_76->setSizePolicy(sizePolicy1);
        label_76->setMinimumSize(QSize(25, 16));
        label_76->setMaximumSize(QSize(25, 16));
        label_76->setFont(font);
        label_76->setTextFormat(Qt::AutoText);
        label_76->setScaledContents(true);
        label_76->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_76->setWordWrap(false);

        gridLayoutNetwork->addWidget(label_76, 0, 0, 1, 1);

        label_77 = new QLabel(groupBoxGridStatusNetwork);
        label_77->setObjectName(QString::fromUtf8("label_77"));
        label_77->setMinimumSize(QSize(25, 16));
        label_77->setMaximumSize(QSize(25, 16));
        label_77->setFont(font);
        label_77->setTextFormat(Qt::AutoText);
        label_77->setScaledContents(true);
        label_77->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_77->setWordWrap(false);

        gridLayoutNetwork->addWidget(label_77, 1, 0, 1, 1);


        gridLayout_45->addLayout(gridLayoutNetwork, 0, 2, 1, 1);


        gridLayout_39->addLayout(gridLayout_45, 0, 0, 1, 1);


        horizontalLayoutStatus->addWidget(groupBoxGridStatusNetwork);

        groupBoxInverterErrorStatus = new QGroupBox(InfoTab);
        groupBoxInverterErrorStatus->setObjectName(QString::fromUtf8("groupBoxInverterErrorStatus"));
        sizePolicy.setHeightForWidth(groupBoxInverterErrorStatus->sizePolicy().hasHeightForWidth());
        groupBoxInverterErrorStatus->setSizePolicy(sizePolicy);
        groupBoxInverterErrorStatus->setMinimumSize(QSize(155, 110));
        groupBoxInverterErrorStatus->setMaximumSize(QSize(16777215, 16777215));
        gridLayout_32 = new QGridLayout(groupBoxInverterErrorStatus);
        gridLayout_32->setSpacing(6);
        gridLayout_32->setContentsMargins(11, 11, 11, 11);
        gridLayout_32->setObjectName(QString::fromUtf8("gridLayout_32"));
        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        gridLayout_33 = new QGridLayout();
        gridLayout_33->setSpacing(6);
        gridLayout_33->setObjectName(QString::fromUtf8("gridLayout_33"));
        label_28 = new QLabel(groupBoxInverterErrorStatus);
        label_28->setObjectName(QString::fromUtf8("label_28"));
        label_28->setFont(font);
        label_28->setTextFormat(Qt::AutoText);
        label_28->setScaledContents(true);
        label_28->setWordWrap(false);

        gridLayout_33->addWidget(label_28, 0, 0, 1, 1);


        horizontalLayout_7->addLayout(gridLayout_33);

        gridLayout_34 = new QGridLayout();
        gridLayout_34->setSpacing(6);
        gridLayout_34->setObjectName(QString::fromUtf8("gridLayout_34"));
        labelErrorCodeValue = new QLabel(groupBoxInverterErrorStatus);
        labelErrorCodeValue->setObjectName(QString::fromUtf8("labelErrorCodeValue"));
        labelErrorCodeValue->setFont(font);
        labelErrorCodeValue->setTextFormat(Qt::AutoText);
        labelErrorCodeValue->setScaledContents(true);
        labelErrorCodeValue->setAlignment(Qt::AlignCenter);
        labelErrorCodeValue->setWordWrap(false);

        gridLayout_34->addWidget(labelErrorCodeValue, 0, 0, 1, 1);


        horizontalLayout_7->addLayout(gridLayout_34);


        gridLayout_32->addLayout(horizontalLayout_7, 0, 0, 1, 1);


        horizontalLayoutStatus->addWidget(groupBoxInverterErrorStatus);


        gridLayout_38->addLayout(horizontalLayoutStatus, 2, 0, 1, 1);

        tabWidget->addTab(InfoTab, QString());
        ConfigTab = new QWidget();
        ConfigTab->setObjectName(QString::fromUtf8("ConfigTab"));
        gridLayout_21 = new QGridLayout(ConfigTab);
        gridLayout_21->setSpacing(6);
        gridLayout_21->setContentsMargins(11, 11, 11, 11);
        gridLayout_21->setObjectName(QString::fromUtf8("gridLayout_21"));
        groupBoxRTC = new QGroupBox(ConfigTab);
        groupBoxRTC->setObjectName(QString::fromUtf8("groupBoxRTC"));
        sizePolicy.setHeightForWidth(groupBoxRTC->sizePolicy().hasHeightForWidth());
        groupBoxRTC->setSizePolicy(sizePolicy);
        groupBoxRTC->setMinimumSize(QSize(220, 100));
        groupBoxRTC->setMaximumSize(QSize(16777215, 16777215));
        gridLayout_35 = new QGridLayout(groupBoxRTC);
        gridLayout_35->setSpacing(6);
        gridLayout_35->setContentsMargins(11, 11, 11, 11);
        gridLayout_35->setObjectName(QString::fromUtf8("gridLayout_35"));
        pushButtonSync = new QPushButton(groupBoxRTC);
        pushButtonSync->setObjectName(QString::fromUtf8("pushButtonSync"));

        gridLayout_35->addWidget(pushButtonSync, 1, 0, 1, 1);

        labelDateTime = new QLabel(groupBoxRTC);
        labelDateTime->setObjectName(QString::fromUtf8("labelDateTime"));
        labelDateTime->setAlignment(Qt::AlignCenter);

        gridLayout_35->addWidget(labelDateTime, 0, 0, 1, 1);


        gridLayout_21->addWidget(groupBoxRTC, 1, 1, 1, 1);

        groupBoxpowerFactor = new QGroupBox(ConfigTab);
        groupBoxpowerFactor->setObjectName(QString::fromUtf8("groupBoxpowerFactor"));
        sizePolicy.setHeightForWidth(groupBoxpowerFactor->sizePolicy().hasHeightForWidth());
        groupBoxpowerFactor->setSizePolicy(sizePolicy);
        gridLayout_37 = new QGridLayout(groupBoxpowerFactor);
        gridLayout_37->setSpacing(6);
        gridLayout_37->setContentsMargins(11, 11, 11, 11);
        gridLayout_37->setObjectName(QString::fromUtf8("gridLayout_37"));
        gridLayout_17 = new QGridLayout();
        gridLayout_17->setSpacing(6);
        gridLayout_17->setObjectName(QString::fromUtf8("gridLayout_17"));
        doubleSpinBoxPowerFactor = new QDoubleSpinBox(groupBoxpowerFactor);
        doubleSpinBoxPowerFactor->setObjectName(QString::fromUtf8("doubleSpinBoxPowerFactor"));
        doubleSpinBoxPowerFactor->setDecimals(4);
        doubleSpinBoxPowerFactor->setMaximum(1.000000000000000);
        doubleSpinBoxPowerFactor->setSingleStep(0.010000000000000);
        doubleSpinBoxPowerFactor->setStepType(QAbstractSpinBox::AdaptiveDecimalStepType);

        gridLayout_17->addWidget(doubleSpinBoxPowerFactor, 1, 0, 1, 1);

        labelStartDelayRange_2 = new QLabel(groupBoxpowerFactor);
        labelStartDelayRange_2->setObjectName(QString::fromUtf8("labelStartDelayRange_2"));
        labelStartDelayRange_2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_17->addWidget(labelStartDelayRange_2, 2, 0, 1, 1);


        gridLayout_37->addLayout(gridLayout_17, 0, 0, 2, 1);

        gridLayout_24 = new QGridLayout();
        gridLayout_24->setSpacing(6);
        gridLayout_24->setObjectName(QString::fromUtf8("gridLayout_24"));
        comboBoxPowerFactor = new QComboBox(groupBoxpowerFactor);
        comboBoxPowerFactor->addItem(QString());
        comboBoxPowerFactor->addItem(QString());
        comboBoxPowerFactor->setObjectName(QString::fromUtf8("comboBoxPowerFactor"));

        gridLayout_24->addWidget(comboBoxPowerFactor, 0, 0, 1, 1);


        gridLayout_37->addLayout(gridLayout_24, 0, 1, 1, 1);

        pushButtonConfPowerFactor = new QPushButton(groupBoxpowerFactor);
        pushButtonConfPowerFactor->setObjectName(QString::fromUtf8("pushButtonConfPowerFactor"));

        gridLayout_37->addWidget(pushButtonConfPowerFactor, 1, 1, 1, 1);


        gridLayout_21->addWidget(groupBoxpowerFactor, 2, 1, 1, 1);

        groupBoxNewConfig = new QGroupBox(ConfigTab);
        groupBoxNewConfig->setObjectName(QString::fromUtf8("groupBoxNewConfig"));
        sizePolicy.setHeightForWidth(groupBoxNewConfig->sizePolicy().hasHeightForWidth());
        groupBoxNewConfig->setSizePolicy(sizePolicy);
        groupBoxNewConfig->setMinimumSize(QSize(250, 180));
        groupBoxNewConfig->setMaximumSize(QSize(16777215, 16777215));
        gridLayout_15 = new QGridLayout(groupBoxNewConfig);
        gridLayout_15->setSpacing(6);
        gridLayout_15->setContentsMargins(11, 11, 11, 11);
        gridLayout_15->setObjectName(QString::fromUtf8("gridLayout_15"));
        comboBoxOutputVoltage = new QComboBox(groupBoxNewConfig);
        comboBoxOutputVoltage->addItem(QString());
        comboBoxOutputVoltage->addItem(QString());
        comboBoxOutputVoltage->addItem(QString());
        comboBoxOutputVoltage->addItem(QString());
        comboBoxOutputVoltage->setObjectName(QString::fromUtf8("comboBoxOutputVoltage"));

        gridLayout_15->addWidget(comboBoxOutputVoltage, 0, 1, 1, 1);

        labelStartDelay = new QLabel(groupBoxNewConfig);
        labelStartDelay->setObjectName(QString::fromUtf8("labelStartDelay"));

        gridLayout_15->addWidget(labelStartDelay, 1, 0, 1, 1);

        lineEditStartDelay = new QLineEdit(groupBoxNewConfig);
        lineEditStartDelay->setObjectName(QString::fromUtf8("lineEditStartDelay"));
        lineEditStartDelay->setAlignment(Qt::AlignCenter);

        gridLayout_15->addWidget(lineEditStartDelay, 1, 1, 2, 1);

        lineEditReconnectTime = new QLineEdit(groupBoxNewConfig);
        lineEditReconnectTime->setObjectName(QString::fromUtf8("lineEditReconnectTime"));
        lineEditReconnectTime->setAlignment(Qt::AlignCenter);

        gridLayout_15->addWidget(lineEditReconnectTime, 3, 1, 2, 1);

        labelStartDelayRange = new QLabel(groupBoxNewConfig);
        labelStartDelayRange->setObjectName(QString::fromUtf8("labelStartDelayRange"));

        gridLayout_15->addWidget(labelStartDelayRange, 2, 0, 1, 1);

        labelOutputVoltage = new QLabel(groupBoxNewConfig);
        labelOutputVoltage->setObjectName(QString::fromUtf8("labelOutputVoltage"));

        gridLayout_15->addWidget(labelOutputVoltage, 0, 0, 1, 1);

        pushButtonConfigure = new QPushButton(groupBoxNewConfig);
        pushButtonConfigure->setObjectName(QString::fromUtf8("pushButtonConfigure"));

        gridLayout_15->addWidget(pushButtonConfigure, 5, 1, 1, 1);

        labelRecconetTimeRange = new QLabel(groupBoxNewConfig);
        labelRecconetTimeRange->setObjectName(QString::fromUtf8("labelRecconetTimeRange"));

        gridLayout_15->addWidget(labelRecconetTimeRange, 5, 0, 1, 1);

        labelRecconetTime = new QLabel(groupBoxNewConfig);
        labelRecconetTime->setObjectName(QString::fromUtf8("labelRecconetTime"));

        gridLayout_15->addWidget(labelRecconetTime, 4, 0, 1, 1);


        gridLayout_21->addWidget(groupBoxNewConfig, 0, 1, 1, 1);

        groupBoxDetailedConfig = new QGroupBox(ConfigTab);
        groupBoxDetailedConfig->setObjectName(QString::fromUtf8("groupBoxDetailedConfig"));
        QSizePolicy sizePolicy2(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy2.setHorizontalStretch(255);
        sizePolicy2.setVerticalStretch(255);
        sizePolicy2.setHeightForWidth(groupBoxDetailedConfig->sizePolicy().hasHeightForWidth());
        groupBoxDetailedConfig->setSizePolicy(sizePolicy2);
        formLayout_3 = new QFormLayout(groupBoxDetailedConfig);
        formLayout_3->setSpacing(6);
        formLayout_3->setContentsMargins(11, 11, 11, 11);
        formLayout_3->setObjectName(QString::fromUtf8("formLayout_3"));
        formLayout_3->setSizeConstraint(QLayout::SetMinAndMaxSize);
        formLayout_3->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
        gridLayout_25 = new QGridLayout();
        gridLayout_25->setSpacing(18);
        gridLayout_25->setObjectName(QString::fromUtf8("gridLayout_25"));
        gridLayout_25->setSizeConstraint(QLayout::SetNoConstraint);
        gridLayout_25->setContentsMargins(-1, 11, -1, 15);
        labelStartDelay_2 = new QLabel(groupBoxDetailedConfig);
        labelStartDelay_2->setObjectName(QString::fromUtf8("labelStartDelay_2"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::Maximum);
        sizePolicy3.setHorizontalStretch(255);
        sizePolicy3.setVerticalStretch(255);
        sizePolicy3.setHeightForWidth(labelStartDelay_2->sizePolicy().hasHeightForWidth());
        labelStartDelay_2->setSizePolicy(sizePolicy3);
        labelStartDelay_2->setMinimumSize(QSize(110, 30));
        labelStartDelay_2->setFocusPolicy(Qt::NoFocus);
        labelStartDelay_2->setLayoutDirection(Qt::LeftToRight);
        labelStartDelay_2->setFrameShape(QFrame::NoFrame);
        labelStartDelay_2->setTextFormat(Qt::AutoText);
        labelStartDelay_2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_25->addWidget(labelStartDelay_2, 1, 0, 1, 1);

        labelOutputVoltageValue = new QLabel(groupBoxDetailedConfig);
        labelOutputVoltageValue->setObjectName(QString::fromUtf8("labelOutputVoltageValue"));
        sizePolicy2.setHeightForWidth(labelOutputVoltageValue->sizePolicy().hasHeightForWidth());
        labelOutputVoltageValue->setSizePolicy(sizePolicy2);
        labelOutputVoltageValue->setMinimumSize(QSize(80, 30));
        labelOutputVoltageValue->setLayoutDirection(Qt::LeftToRight);
        labelOutputVoltageValue->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_25->addWidget(labelOutputVoltageValue, 0, 1, 1, 1);

        labelReconnectTime_2 = new QLabel(groupBoxDetailedConfig);
        labelReconnectTime_2->setObjectName(QString::fromUtf8("labelReconnectTime_2"));
        QSizePolicy sizePolicy4(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy4.setHorizontalStretch(255);
        sizePolicy4.setVerticalStretch(255);
        sizePolicy4.setHeightForWidth(labelReconnectTime_2->sizePolicy().hasHeightForWidth());
        labelReconnectTime_2->setSizePolicy(sizePolicy4);
        labelReconnectTime_2->setMinimumSize(QSize(130, 30));

        gridLayout_25->addWidget(labelReconnectTime_2, 2, 0, 1, 1);

        labelOutputVoltage_2 = new QLabel(groupBoxDetailedConfig);
        labelOutputVoltage_2->setObjectName(QString::fromUtf8("labelOutputVoltage_2"));
        sizePolicy4.setHeightForWidth(labelOutputVoltage_2->sizePolicy().hasHeightForWidth());
        labelOutputVoltage_2->setSizePolicy(sizePolicy4);
        labelOutputVoltage_2->setMinimumSize(QSize(110, 30));
        labelOutputVoltage_2->setInputMethodHints(Qt::ImhNone);
        labelOutputVoltage_2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_25->addWidget(labelOutputVoltage_2, 0, 0, 1, 1);

        labelStartDelayValue = new QLabel(groupBoxDetailedConfig);
        labelStartDelayValue->setObjectName(QString::fromUtf8("labelStartDelayValue"));
        sizePolicy2.setHeightForWidth(labelStartDelayValue->sizePolicy().hasHeightForWidth());
        labelStartDelayValue->setSizePolicy(sizePolicy2);
        labelStartDelayValue->setMinimumSize(QSize(80, 30));
        labelStartDelayValue->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_25->addWidget(labelStartDelayValue, 1, 1, 1, 1);

        labelReconnectTime = new QLabel(groupBoxDetailedConfig);
        labelReconnectTime->setObjectName(QString::fromUtf8("labelReconnectTime"));
        sizePolicy2.setHeightForWidth(labelReconnectTime->sizePolicy().hasHeightForWidth());
        labelReconnectTime->setSizePolicy(sizePolicy2);
        labelReconnectTime->setMinimumSize(QSize(80, 30));

        gridLayout_25->addWidget(labelReconnectTime, 2, 1, 1, 1);


        formLayout_3->setLayout(0, QFormLayout::SpanningRole, gridLayout_25);

        gridLayout_42 = new QGridLayout();
        gridLayout_42->setSpacing(6);
        gridLayout_42->setObjectName(QString::fromUtf8("gridLayout_42"));
        gridLayout_42->setSizeConstraint(QLayout::SetMinAndMaxSize);
        gridLayout_42->setVerticalSpacing(7);
        gridLayout_42->setContentsMargins(-1, 0, -1, 0);
        widget3 = new QWidget(groupBoxDetailedConfig);
        widget3->setObjectName(QString::fromUtf8("widget3"));
        widget3->setEnabled(true);
        sizePolicy4.setHeightForWidth(widget3->sizePolicy().hasHeightForWidth());
        widget3->setSizePolicy(sizePolicy4);
        widget3->setMinimumSize(QSize(100, 100));
        QFont font1;
        font1.setStyleStrategy(QFont::PreferDefault);
        widget3->setFont(font1);
        widget3->setLayoutDirection(Qt::LeftToRight);
        formLayout_4 = new QFormLayout(widget3);
        formLayout_4->setSpacing(6);
        formLayout_4->setContentsMargins(11, 11, 11, 11);
        formLayout_4->setObjectName(QString::fromUtf8("formLayout_4"));
        formLayout_4->setSizeConstraint(QLayout::SetMinAndMaxSize);
        formLayout_4->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
        formLayout_4->setLabelAlignment(Qt::AlignJustify|Qt::AlignVCenter);
        formLayout_4->setFormAlignment(Qt::AlignJustify|Qt::AlignTop);
        formLayout_4->setContentsMargins(28, 9, -1, -1);
        labelPowerFactorCurveValue = new QLabel(widget3);
        labelPowerFactorCurveValue->setObjectName(QString::fromUtf8("labelPowerFactorCurveValue"));
        QFont font2;
        font2.setPointSize(8);
        font2.setStyleStrategy(QFont::PreferDefault);
        labelPowerFactorCurveValue->setFont(font2);
        labelPowerFactorCurveValue->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        labelPowerFactorCurveValue->setMargin(2);
        labelPowerFactorCurveValue->setIndent(0);

        formLayout_4->setWidget(6, QFormLayout::LabelRole, labelPowerFactorCurveValue);

        labelOverFrequencyValue = new QLabel(widget3);
        labelOverFrequencyValue->setObjectName(QString::fromUtf8("labelOverFrequencyValue"));
        labelOverFrequencyValue->setFont(font2);
        labelOverFrequencyValue->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        labelOverFrequencyValue->setMargin(2);
        labelOverFrequencyValue->setIndent(0);

        formLayout_4->setWidget(2, QFormLayout::LabelRole, labelOverFrequencyValue);

        labelUnderVoltageValue = new QLabel(widget3);
        labelUnderVoltageValue->setObjectName(QString::fromUtf8("labelUnderVoltageValue"));
        labelUnderVoltageValue->setFont(font2);
        labelUnderVoltageValue->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        labelUnderVoltageValue->setMargin(2);
        labelUnderVoltageValue->setIndent(0);

        formLayout_4->setWidget(1, QFormLayout::LabelRole, labelUnderVoltageValue);

        labelUnderFrequencyValue = new QLabel(widget3);
        labelUnderFrequencyValue->setObjectName(QString::fromUtf8("labelUnderFrequencyValue"));
        labelUnderFrequencyValue->setFont(font2);
        labelUnderFrequencyValue->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        labelUnderFrequencyValue->setMargin(2);
        labelUnderFrequencyValue->setIndent(0);

        formLayout_4->setWidget(3, QFormLayout::LabelRole, labelUnderFrequencyValue);

        labelPowerFactorValue = new QLabel(widget3);
        labelPowerFactorValue->setObjectName(QString::fromUtf8("labelPowerFactorValue"));
        labelPowerFactorValue->setFont(font2);
        labelPowerFactorValue->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        labelPowerFactorValue->setMargin(2);
        labelPowerFactorValue->setIndent(0);

        formLayout_4->setWidget(5, QFormLayout::LabelRole, labelPowerFactorValue);

        labelOverVoltageValue = new QLabel(widget3);
        labelOverVoltageValue->setObjectName(QString::fromUtf8("labelOverVoltageValue"));
        labelOverVoltageValue->setFont(font2);
        labelOverVoltageValue->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        labelOverVoltageValue->setMargin(2);
        labelOverVoltageValue->setIndent(0);

        formLayout_4->setWidget(0, QFormLayout::LabelRole, labelOverVoltageValue);

        labelAntiIslandingValue = new QLabel(widget3);
        labelAntiIslandingValue->setObjectName(QString::fromUtf8("labelAntiIslandingValue"));
        labelAntiIslandingValue->setFont(font2);
        labelAntiIslandingValue->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        labelAntiIslandingValue->setMargin(2);
        labelAntiIslandingValue->setIndent(0);

        formLayout_4->setWidget(4, QFormLayout::LabelRole, labelAntiIslandingValue);


        gridLayout_42->addWidget(widget3, 0, 1, 1, 1);

        widget2 = new QWidget(groupBoxDetailedConfig);
        widget2->setObjectName(QString::fromUtf8("widget2"));
        sizePolicy4.setHeightForWidth(widget2->sizePolicy().hasHeightForWidth());
        widget2->setSizePolicy(sizePolicy4);
        widget2->setMinimumSize(QSize(130, 80));
        QFont font3;
        font3.setStyleStrategy(QFont::PreferAntialias);
        widget2->setFont(font3);
        widget2->setFocusPolicy(Qt::NoFocus);
        formLayout_5 = new QFormLayout(widget2);
        formLayout_5->setSpacing(6);
        formLayout_5->setContentsMargins(11, 11, 11, 11);
        formLayout_5->setObjectName(QString::fromUtf8("formLayout_5"));
        formLayout_5->setSizeConstraint(QLayout::SetMinAndMaxSize);
        formLayout_5->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
        formLayout_5->setRowWrapPolicy(QFormLayout::DontWrapRows);
        formLayout_5->setLabelAlignment(Qt::AlignJustify|Qt::AlignVCenter);
        formLayout_5->setFormAlignment(Qt::AlignJustify|Qt::AlignTop);
        formLayout_5->setHorizontalSpacing(7);
        formLayout_5->setContentsMargins(4, 10, 7, -1);
        labelOverFrequency = new QLabel(widget2);
        labelOverFrequency->setObjectName(QString::fromUtf8("labelOverFrequency"));
        QFont font4;
        font4.setPointSize(8);
        font4.setStyleStrategy(QFont::PreferAntialias);
        labelOverFrequency->setFont(font4);
        labelOverFrequency->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelOverFrequency->setMargin(2);
        labelOverFrequency->setIndent(0);

        formLayout_5->setWidget(2, QFormLayout::LabelRole, labelOverFrequency);

        labelAntiIslanding = new QLabel(widget2);
        labelAntiIslanding->setObjectName(QString::fromUtf8("labelAntiIslanding"));
        labelAntiIslanding->setFont(font4);
        labelAntiIslanding->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelAntiIslanding->setMargin(2);
        labelAntiIslanding->setIndent(0);

        formLayout_5->setWidget(4, QFormLayout::LabelRole, labelAntiIslanding);

        labelUnderVoltage = new QLabel(widget2);
        labelUnderVoltage->setObjectName(QString::fromUtf8("labelUnderVoltage"));
        labelUnderVoltage->setFont(font4);
        labelUnderVoltage->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelUnderVoltage->setMargin(2);
        labelUnderVoltage->setIndent(0);

        formLayout_5->setWidget(1, QFormLayout::LabelRole, labelUnderVoltage);

        labelPowerFactor = new QLabel(widget2);
        labelPowerFactor->setObjectName(QString::fromUtf8("labelPowerFactor"));
        labelPowerFactor->setFont(font4);
        labelPowerFactor->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelPowerFactor->setMargin(2);
        labelPowerFactor->setIndent(0);

        formLayout_5->setWidget(5, QFormLayout::LabelRole, labelPowerFactor);

        labelPowerFactorCurve = new QLabel(widget2);
        labelPowerFactorCurve->setObjectName(QString::fromUtf8("labelPowerFactorCurve"));
        labelPowerFactorCurve->setFont(font4);
        labelPowerFactorCurve->setWordWrap(true);
        labelPowerFactorCurve->setMargin(2);
        labelPowerFactorCurve->setIndent(0);

        formLayout_5->setWidget(6, QFormLayout::LabelRole, labelPowerFactorCurve);

        labelUnderFrequency = new QLabel(widget2);
        labelUnderFrequency->setObjectName(QString::fromUtf8("labelUnderFrequency"));
        labelUnderFrequency->setFont(font4);
        labelUnderFrequency->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelUnderFrequency->setMargin(2);
        labelUnderFrequency->setIndent(0);

        formLayout_5->setWidget(3, QFormLayout::LabelRole, labelUnderFrequency);

        labelOverVoltage = new QLabel(widget2);
        labelOverVoltage->setObjectName(QString::fromUtf8("labelOverVoltage"));
        labelOverVoltage->setFont(font4);
        labelOverVoltage->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        labelOverVoltage->setMargin(2);
        labelOverVoltage->setIndent(0);

        formLayout_5->setWidget(0, QFormLayout::LabelRole, labelOverVoltage);


        gridLayout_42->addWidget(widget2, 0, 0, 1, 1);


        formLayout_3->setLayout(1, QFormLayout::SpanningRole, gridLayout_42);


        gridLayout_21->addWidget(groupBoxDetailedConfig, 0, 0, 3, 1);

        tabWidget->addTab(ConfigTab, QString());
        AboutTab = new QWidget();
        AboutTab->setObjectName(QString::fromUtf8("AboutTab"));
        gridLayout_40 = new QGridLayout(AboutTab);
        gridLayout_40->setSpacing(6);
        gridLayout_40->setContentsMargins(11, 11, 11, 11);
        gridLayout_40->setObjectName(QString::fromUtf8("gridLayout_40"));
        gridLayout_41 = new QGridLayout();
        gridLayout_41->setSpacing(6);
        gridLayout_41->setObjectName(QString::fromUtf8("gridLayout_41"));
        gridLayout_41->setSizeConstraint(QLayout::SetMinAndMaxSize);
        labelNHSLogo = new QLabel(AboutTab);
        labelNHSLogo->setObjectName(QString::fromUtf8("labelNHSLogo"));
        QSizePolicy sizePolicy5(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(labelNHSLogo->sizePolicy().hasHeightForWidth());
        labelNHSLogo->setSizePolicy(sizePolicy5);
        labelNHSLogo->setLayoutDirection(Qt::LeftToRight);
        labelNHSLogo->setPixmap(QPixmap(QString::fromUtf8(":/resources/img/logo_nhs.png")));
        labelNHSLogo->setAlignment(Qt::AlignCenter);

        gridLayout_41->addWidget(labelNHSLogo, 0, 0, 1, 1);

        layoutAboutLabels = new QFormLayout();
        layoutAboutLabels->setSpacing(6);
        layoutAboutLabels->setObjectName(QString::fromUtf8("layoutAboutLabels"));
        fwVersionLabel = new QLabel(AboutTab);
        fwVersionLabel->setObjectName(QString::fromUtf8("fwVersionLabel"));
        sizePolicy.setHeightForWidth(fwVersionLabel->sizePolicy().hasHeightForWidth());
        fwVersionLabel->setSizePolicy(sizePolicy);
        fwVersionLabel->setMinimumSize(QSize(100, 30));
        QFont font5;
        font5.setBold(true);
        font5.setWeight(75);
        fwVersionLabel->setFont(font5);

        layoutAboutLabels->setWidget(0, QFormLayout::LabelRole, fwVersionLabel);

        fwVersionLineEdit = new QLineEdit(AboutTab);
        fwVersionLineEdit->setObjectName(QString::fromUtf8("fwVersionLineEdit"));
        QSizePolicy sizePolicy6(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy6.setHorizontalStretch(255);
        sizePolicy6.setVerticalStretch(255);
        sizePolicy6.setHeightForWidth(fwVersionLineEdit->sizePolicy().hasHeightForWidth());
        fwVersionLineEdit->setSizePolicy(sizePolicy6);
        fwVersionLineEdit->setMinimumSize(QSize(100, 30));
        fwVersionLineEdit->setFrame(false);
        fwVersionLineEdit->setReadOnly(true);

        layoutAboutLabels->setWidget(0, QFormLayout::FieldRole, fwVersionLineEdit);

        modelLabel = new QLabel(AboutTab);
        modelLabel->setObjectName(QString::fromUtf8("modelLabel"));
        sizePolicy.setHeightForWidth(modelLabel->sizePolicy().hasHeightForWidth());
        modelLabel->setSizePolicy(sizePolicy);
        modelLabel->setMinimumSize(QSize(100, 30));
        modelLabel->setFont(font5);

        layoutAboutLabels->setWidget(1, QFormLayout::LabelRole, modelLabel);

        modelLineEdit = new QLineEdit(AboutTab);
        modelLineEdit->setObjectName(QString::fromUtf8("modelLineEdit"));
        QSizePolicy sizePolicy7(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy7.setHorizontalStretch(0);
        sizePolicy7.setVerticalStretch(0);
        sizePolicy7.setHeightForWidth(modelLineEdit->sizePolicy().hasHeightForWidth());
        modelLineEdit->setSizePolicy(sizePolicy7);
        modelLineEdit->setMinimumSize(QSize(100, 30));
        modelLineEdit->setLayoutDirection(Qt::LeftToRight);
        modelLineEdit->setFrame(false);
        modelLineEdit->setReadOnly(true);

        layoutAboutLabels->setWidget(1, QFormLayout::FieldRole, modelLineEdit);

        serialNumberLabel = new QLabel(AboutTab);
        serialNumberLabel->setObjectName(QString::fromUtf8("serialNumberLabel"));
        serialNumberLabel->setMinimumSize(QSize(100, 30));
        serialNumberLabel->setFont(font5);

        layoutAboutLabels->setWidget(2, QFormLayout::LabelRole, serialNumberLabel);

        serialNumberLineEdit = new QLineEdit(AboutTab);
        serialNumberLineEdit->setObjectName(QString::fromUtf8("serialNumberLineEdit"));
        sizePolicy6.setHeightForWidth(serialNumberLineEdit->sizePolicy().hasHeightForWidth());
        serialNumberLineEdit->setSizePolicy(sizePolicy6);
        serialNumberLineEdit->setMinimumSize(QSize(100, 30));
        serialNumberLineEdit->setFrame(false);
        serialNumberLineEdit->setReadOnly(true);

        layoutAboutLabels->setWidget(2, QFormLayout::FieldRole, serialNumberLineEdit);


        gridLayout_41->addLayout(layoutAboutLabels, 1, 0, 1, 1);


        gridLayout_40->addLayout(gridLayout_41, 0, 0, 1, 1);

        tabWidget->addTab(AboutTab, QString());

        gridLayout_20->addWidget(tabWidget, 0, 0, 1, 1);

        InverterConfigMain->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(InverterConfigMain);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 612, 21));
        menuOp_es = new QMenu(menuBar);
        menuOp_es->setObjectName(QString::fromUtf8("menuOp_es"));
        InverterConfigMain->setMenuBar(menuBar);
        statusBar = new QStatusBar(InverterConfigMain);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        InverterConfigMain->setStatusBar(statusBar);

        menuBar->addAction(menuOp_es->menuAction());
        menuOp_es->addAction(actionConnect);
        menuOp_es->addAction(actionDisconnect);
        menuOp_es->addAction(actionSerialConfig);

        retranslateUi(InverterConfigMain);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(InverterConfigMain);
    } // setupUi

    void retranslateUi(QMainWindow *InverterConfigMain)
    {
        InverterConfigMain->setWindowTitle(QApplication::translate("InverterConfigMain", "Configura\303\247\303\243o Inversor", nullptr));
        actionConnect->setText(QApplication::translate("InverterConfigMain", "Conectar", nullptr));
        actionDisconnect->setText(QApplication::translate("InverterConfigMain", "Desconectar", nullptr));
        ScanPorts->setText(QApplication::translate("InverterConfigMain", "Procurar Portas", nullptr));
        actionSerialConfig->setText(QApplication::translate("InverterConfigMain", "Configura\303\247\303\243o Serial", nullptr));
        groupBoxPV1->setTitle(QApplication::translate("InverterConfigMain", "PV1", nullptr));
        labelPV1Voltage->setText(QApplication::translate("InverterConfigMain", "Tens\303\243o:", nullptr));
        labelPV1Current->setText(QApplication::translate("InverterConfigMain", "Corrente:", nullptr));
        labelPV1VoltageValue->setText(QApplication::translate("InverterConfigMain", "0,0", nullptr));
        labelPV1CurrentValue->setText(QApplication::translate("InverterConfigMain", "0,0", nullptr));
        label_58->setText(QApplication::translate("InverterConfigMain", "V", nullptr));
        label_59->setText(QApplication::translate("InverterConfigMain", "A", nullptr));
        groupBoxPV2->setTitle(QApplication::translate("InverterConfigMain", "PV2", nullptr));
        labelPV1Voltage_2->setText(QApplication::translate("InverterConfigMain", "Tens\303\243o:", nullptr));
        labelPV1Current_2->setText(QApplication::translate("InverterConfigMain", "Corrente:", nullptr));
        labelPV2VoltageValue->setText(QApplication::translate("InverterConfigMain", "0,0", nullptr));
        labelPV2CurrentValue->setText(QApplication::translate("InverterConfigMain", "0,0", nullptr));
        label_60->setText(QApplication::translate("InverterConfigMain", "V", nullptr));
        label_61->setText(QApplication::translate("InverterConfigMain", "A", nullptr));
        groupBoxPhaseL1->setTitle(QApplication::translate("InverterConfigMain", "Fase L1", nullptr));
        label_11->setText(QApplication::translate("InverterConfigMain", "Frequ\303\252ncia:", nullptr));
        label_8->setText(QApplication::translate("InverterConfigMain", "Corrente:", nullptr));
        label_5->setText(QApplication::translate("InverterConfigMain", "Tens\303\243o:", nullptr));
        labelVoltageL1Value->setText(QApplication::translate("InverterConfigMain", "0,0", nullptr));
        labelCurrentL1Value->setText(QApplication::translate("InverterConfigMain", "0,0", nullptr));
        labelFrequencyL1Value->setText(QApplication::translate("InverterConfigMain", "0,0", nullptr));
        label_40->setText(QApplication::translate("InverterConfigMain", "V", nullptr));
        label_46->setText(QApplication::translate("InverterConfigMain", "Hz", nullptr));
        label_43->setText(QApplication::translate("InverterConfigMain", "A", nullptr));
        groupBoxPhaseL2->setTitle(QApplication::translate("InverterConfigMain", "Fase L2", nullptr));
        label_12->setText(QApplication::translate("InverterConfigMain", "Frequ\303\252ncia:", nullptr));
        label_9->setText(QApplication::translate("InverterConfigMain", "Corrente:", nullptr));
        label_6->setText(QApplication::translate("InverterConfigMain", "Tens\303\243o:", nullptr));
        labelVoltageL2Value->setText(QApplication::translate("InverterConfigMain", "0,0", nullptr));
        labelCurrentL2Value->setText(QApplication::translate("InverterConfigMain", "0,0", nullptr));
        labelFrequencyL2Value->setText(QApplication::translate("InverterConfigMain", "0,0", nullptr));
        label_41->setText(QApplication::translate("InverterConfigMain", "V", nullptr));
        label_47->setText(QApplication::translate("InverterConfigMain", "Hz", nullptr));
        label_44->setText(QApplication::translate("InverterConfigMain", "A", nullptr));
        groupBoxPhaseL3->setTitle(QApplication::translate("InverterConfigMain", "Fase L3", nullptr));
        label_13->setText(QApplication::translate("InverterConfigMain", "Frequ\303\252ncia:", nullptr));
        label_10->setText(QApplication::translate("InverterConfigMain", "Corrente:", nullptr));
        label_7->setText(QApplication::translate("InverterConfigMain", "Tens\303\243o:", nullptr));
        labelVoltageL3Value->setText(QApplication::translate("InverterConfigMain", "0,0", nullptr));
        labelCurrentL3Value->setText(QApplication::translate("InverterConfigMain", "0,0", nullptr));
        labelFrequencyL3Value->setText(QApplication::translate("InverterConfigMain", "0,0", nullptr));
        label_42->setText(QApplication::translate("InverterConfigMain", "V", nullptr));
        label_48->setText(QApplication::translate("InverterConfigMain", "Hz", nullptr));
        label_45->setText(QApplication::translate("InverterConfigMain", "A", nullptr));
        groupBoxInverterStatus->setTitle(QApplication::translate("InverterConfigMain", "Status inversor", nullptr));
        label_25->setText(QApplication::translate("InverterConfigMain", "T. (\302\260C):", nullptr));
        label_24->setText(QApplication::translate("InverterConfigMain", "Modo:", nullptr));
        label_26->setText(QApplication::translate("InverterConfigMain", "C\303\263d Pa\303\255s:", nullptr));
        labelCountryCodeValue->setText(QString());
        labelTemperatureValue->setText(QString());
        labelWorkModeValue->setText(QString());
        groupBoxGridStatusNetwork->setTitle(QApplication::translate("InverterConfigMain", "Status rede", nullptr));
        label_29->setText(QApplication::translate("InverterConfigMain", "Tempo:", nullptr));
        label_33->setText(QApplication::translate("InverterConfigMain", "Energia:", nullptr));
        labelFeedingHoursValue->setText(QApplication::translate("InverterConfigMain", "0", nullptr));
        labelFeedEnergyValue->setText(QApplication::translate("InverterConfigMain", "0,0", nullptr));
        label_76->setText(QApplication::translate("InverterConfigMain", "h", nullptr));
        label_77->setText(QApplication::translate("InverterConfigMain", "KWh", nullptr));
        groupBoxInverterErrorStatus->setTitle(QApplication::translate("InverterConfigMain", "Status erro", nullptr));
        label_28->setText(QApplication::translate("InverterConfigMain", "C\303\263digo:", nullptr));
        labelErrorCodeValue->setText(QApplication::translate("InverterConfigMain", "00000000", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(InfoTab), QApplication::translate("InverterConfigMain", "Informa\303\247\303\265es", nullptr));
        groupBoxRTC->setTitle(QApplication::translate("InverterConfigMain", "RTC", nullptr));
        pushButtonSync->setText(QApplication::translate("InverterConfigMain", "Sincronizar", nullptr));
        labelDateTime->setText(QString());
        groupBoxpowerFactor->setTitle(QApplication::translate("InverterConfigMain", "Fator de Pot\303\252ncia", nullptr));
        labelStartDelayRange_2->setText(QApplication::translate("InverterConfigMain", "0.0000 ~ 1.0000", nullptr));
        comboBoxPowerFactor->setItemText(0, QApplication::translate("InverterConfigMain", "Indutivo", nullptr));
        comboBoxPowerFactor->setItemText(1, QApplication::translate("InverterConfigMain", "Capacitivo", nullptr));

        pushButtonConfPowerFactor->setText(QApplication::translate("InverterConfigMain", "Configurar", nullptr));
        groupBoxNewConfig->setTitle(QApplication::translate("InverterConfigMain", "Nova Configura\303\247\303\243o", nullptr));
        comboBoxOutputVoltage->setItemText(0, QApplication::translate("InverterConfigMain", "220/127V", nullptr));
        comboBoxOutputVoltage->setItemText(1, QApplication::translate("InverterConfigMain", "230/115V", nullptr));
        comboBoxOutputVoltage->setItemText(2, QApplication::translate("InverterConfigMain", "240/120V", nullptr));
        comboBoxOutputVoltage->setItemText(3, QApplication::translate("InverterConfigMain", "254/127V", nullptr));

        labelStartDelay->setText(QApplication::translate("InverterConfigMain", "Atraso Inicial:", nullptr));
        labelStartDelayRange->setText(QApplication::translate("InverterConfigMain", "20 ~ 300s", nullptr));
        labelOutputVoltage->setText(QApplication::translate("InverterConfigMain", "Tens\303\243o de S\303\241ida:", nullptr));
        pushButtonConfigure->setText(QApplication::translate("InverterConfigMain", "Configurar", nullptr));
        labelRecconetTimeRange->setText(QApplication::translate("InverterConfigMain", "20 ~ 300s", nullptr));
        labelRecconetTime->setText(QApplication::translate("InverterConfigMain", "Tempo de Reconex\303\243o", nullptr));
        groupBoxDetailedConfig->setTitle(QApplication::translate("InverterConfigMain", "Configura\303\247\303\243o detalhada (sa\303\255da)", nullptr));
        labelStartDelay_2->setText(QApplication::translate("InverterConfigMain", "Atraso Inicial (s):", nullptr));
        labelOutputVoltageValue->setText(QString());
        labelReconnectTime_2->setText(QApplication::translate("InverterConfigMain", "Tempo Reconex\303\243o(s):", nullptr));
        labelOutputVoltage_2->setText(QApplication::translate("InverterConfigMain", "Tens\303\243o de Sa\303\255da:", nullptr));
        labelStartDelayValue->setText(QString());
        labelReconnectTime->setText(QString());
        labelPowerFactorCurveValue->setText(QApplication::translate("InverterConfigMain", "Desabilitada", nullptr));
        labelOverFrequencyValue->setText(QApplication::translate("InverterConfigMain", "000,0 Hz", nullptr));
        labelUnderVoltageValue->setText(QApplication::translate("InverterConfigMain", "000,0 V", nullptr));
        labelUnderFrequencyValue->setText(QApplication::translate("InverterConfigMain", "000,0 Hz", nullptr));
        labelPowerFactorValue->setText(QApplication::translate("InverterConfigMain", "Unit\303\241rio", nullptr));
        labelOverVoltageValue->setText(QApplication::translate("InverterConfigMain", "000,0 V", nullptr));
        labelAntiIslandingValue->setText(QApplication::translate("InverterConfigMain", "2 s", nullptr));
        labelOverFrequency->setText(QApplication::translate("InverterConfigMain", "Sobrefrequ\303\252ncia (0,2s):", nullptr));
        labelAntiIslanding->setText(QApplication::translate("InverterConfigMain", "Anti-ilhamento:", nullptr));
        labelUnderVoltage->setText(QApplication::translate("InverterConfigMain", "Subtens\303\243o (0,4s):", nullptr));
        labelPowerFactor->setText(QApplication::translate("InverterConfigMain", "Fator Pot\303\252ncia (FP):", nullptr));
        labelPowerFactorCurve->setText(QApplication::translate("InverterConfigMain", "Curva Fator Pot\303\252ncia (FP):", nullptr));
        labelUnderFrequency->setText(QApplication::translate("InverterConfigMain", "Subfrequ\303\252ncia (0,2s):", nullptr));
        labelOverVoltage->setText(QApplication::translate("InverterConfigMain", "Sobretens\303\243o (0,2s):", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(ConfigTab), QApplication::translate("InverterConfigMain", "Configura\303\247\303\243o", nullptr));
        labelNHSLogo->setText(QString());
        fwVersionLabel->setText(QApplication::translate("InverterConfigMain", "Vers\303\243o FW: ", nullptr));
        modelLabel->setText(QApplication::translate("InverterConfigMain", "Modelo:", nullptr));
        serialNumberLabel->setText(QApplication::translate("InverterConfigMain", "N\303\272mero de s\303\251rie:", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(AboutTab), QApplication::translate("InverterConfigMain", "Sobre", nullptr));
        menuOp_es->setTitle(QApplication::translate("InverterConfigMain", "Op\303\247\303\265es", nullptr));
    } // retranslateUi

};

namespace Ui {
    class InverterConfigMain: public Ui_InverterConfigMain {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INVERTERCONFIGMAIN_H
