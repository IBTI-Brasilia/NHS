/********************************************************************************
** Form generated from reading UI file 'dialogserialconfig.ui'
**
** Created by: Qt User Interface Compiler version 5.12.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGSERIALCONFIG_H
#define UI_DIALOGSERIALCONFIG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_DialogSerialConfig
{
public:
    QPushButton *actualParamButton;
    QGroupBox *parametersBox;
    QGridLayout *gridLayout_21;
    QLabel *dataBitsLabel;
    QComboBox *stopBitsBox;
    QLabel *parityLabel;
    QComboBox *parityBox;
    QComboBox *flowControlBox;
    QComboBox *baudRateBox;
    QComboBox *dataBitsBox;
    QPushButton *applyButton;
    QLabel *stopBitsLabel;
    QLabel *flowControlLabel;
    QLabel *baudRateLabel;
    QGroupBox *selectBox;
    QPushButton *conectSerialButton;
    QComboBox *serialPortInfoListBox;
    QPushButton *DesconectButton;

    void setupUi(QDialog *DialogSerialConfig)
    {
        if (DialogSerialConfig->objectName().isEmpty())
            DialogSerialConfig->setObjectName(QString::fromUtf8("DialogSerialConfig"));
        DialogSerialConfig->resize(493, 303);
        actualParamButton = new QPushButton(DialogSerialConfig);
        actualParamButton->setObjectName(QString::fromUtf8("actualParamButton"));
        actualParamButton->setGeometry(QRect(290, 250, 161, 31));
        parametersBox = new QGroupBox(DialogSerialConfig);
        parametersBox->setObjectName(QString::fromUtf8("parametersBox"));
        parametersBox->setGeometry(QRect(10, 20, 231, 261));
        gridLayout_21 = new QGridLayout(parametersBox);
        gridLayout_21->setObjectName(QString::fromUtf8("gridLayout_21"));
        dataBitsLabel = new QLabel(parametersBox);
        dataBitsLabel->setObjectName(QString::fromUtf8("dataBitsLabel"));

        gridLayout_21->addWidget(dataBitsLabel, 1, 0, 1, 1);

        stopBitsBox = new QComboBox(parametersBox);
        stopBitsBox->setObjectName(QString::fromUtf8("stopBitsBox"));

        gridLayout_21->addWidget(stopBitsBox, 3, 2, 1, 1);

        parityLabel = new QLabel(parametersBox);
        parityLabel->setObjectName(QString::fromUtf8("parityLabel"));

        gridLayout_21->addWidget(parityLabel, 2, 0, 1, 1);

        parityBox = new QComboBox(parametersBox);
        parityBox->setObjectName(QString::fromUtf8("parityBox"));

        gridLayout_21->addWidget(parityBox, 2, 2, 1, 1);

        flowControlBox = new QComboBox(parametersBox);
        flowControlBox->setObjectName(QString::fromUtf8("flowControlBox"));

        gridLayout_21->addWidget(flowControlBox, 4, 2, 1, 1);

        baudRateBox = new QComboBox(parametersBox);
        baudRateBox->setObjectName(QString::fromUtf8("baudRateBox"));

        gridLayout_21->addWidget(baudRateBox, 0, 2, 1, 1);

        dataBitsBox = new QComboBox(parametersBox);
        dataBitsBox->setObjectName(QString::fromUtf8("dataBitsBox"));

        gridLayout_21->addWidget(dataBitsBox, 1, 2, 1, 1);

        applyButton = new QPushButton(parametersBox);
        applyButton->setObjectName(QString::fromUtf8("applyButton"));

        gridLayout_21->addWidget(applyButton, 5, 1, 1, 1);

        stopBitsLabel = new QLabel(parametersBox);
        stopBitsLabel->setObjectName(QString::fromUtf8("stopBitsLabel"));

        gridLayout_21->addWidget(stopBitsLabel, 3, 0, 1, 2);

        flowControlLabel = new QLabel(parametersBox);
        flowControlLabel->setObjectName(QString::fromUtf8("flowControlLabel"));

        gridLayout_21->addWidget(flowControlLabel, 4, 0, 1, 2);

        baudRateLabel = new QLabel(parametersBox);
        baudRateLabel->setObjectName(QString::fromUtf8("baudRateLabel"));

        gridLayout_21->addWidget(baudRateLabel, 0, 0, 1, 2);

        selectBox = new QGroupBox(DialogSerialConfig);
        selectBox->setObjectName(QString::fromUtf8("selectBox"));
        selectBox->setGeometry(QRect(260, 20, 221, 211));
        selectBox->setMaximumSize(QSize(16777215, 231));
        conectSerialButton = new QPushButton(selectBox);
        conectSerialButton->setObjectName(QString::fromUtf8("conectSerialButton"));
        conectSerialButton->setGeometry(QRect(60, 100, 101, 31));
        conectSerialButton->setIconSize(QSize(36, 36));
        conectSerialButton->setAutoDefault(false);
        serialPortInfoListBox = new QComboBox(selectBox);
        serialPortInfoListBox->setObjectName(QString::fromUtf8("serialPortInfoListBox"));
        serialPortInfoListBox->setGeometry(QRect(22, 57, 181, 22));
        DesconectButton = new QPushButton(selectBox);
        DesconectButton->setObjectName(QString::fromUtf8("DesconectButton"));
        DesconectButton->setGeometry(QRect(60, 160, 101, 31));
        DesconectButton->setMinimumSize(QSize(0, 21));
        serialPortInfoListBox->raise();
        DesconectButton->raise();
        conectSerialButton->raise();

        retranslateUi(DialogSerialConfig);

        QMetaObject::connectSlotsByName(DialogSerialConfig);
    } // setupUi

    void retranslateUi(QDialog *DialogSerialConfig)
    {
        DialogSerialConfig->setWindowTitle(QApplication::translate("DialogSerialConfig", "Dialog", nullptr));
        actualParamButton->setText(QApplication::translate("DialogSerialConfig", "Par\303\242metros Atuais", nullptr));
        parametersBox->setTitle(QApplication::translate("DialogSerialConfig", "Par\303\242metros Serial", nullptr));
        dataBitsLabel->setText(QApplication::translate("DialogSerialConfig", "Data bits:", nullptr));
        parityLabel->setText(QApplication::translate("DialogSerialConfig", "Paridade:", nullptr));
        applyButton->setText(QApplication::translate("DialogSerialConfig", "Configurar", nullptr));
        stopBitsLabel->setText(QApplication::translate("DialogSerialConfig", "Bit de parada:", nullptr));
        flowControlLabel->setText(QApplication::translate("DialogSerialConfig", "Controle de Fluxo:", nullptr));
        baudRateLabel->setText(QApplication::translate("DialogSerialConfig", "BaudRate:", nullptr));
        selectBox->setTitle(QApplication::translate("DialogSerialConfig", "Portal Serial", nullptr));
        conectSerialButton->setText(QApplication::translate("DialogSerialConfig", "Conectar", nullptr));
        DesconectButton->setText(QApplication::translate("DialogSerialConfig", "Desconectar", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogSerialConfig: public Ui_DialogSerialConfig {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGSERIALCONFIG_H
